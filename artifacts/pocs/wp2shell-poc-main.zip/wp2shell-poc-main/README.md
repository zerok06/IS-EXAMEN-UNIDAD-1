
# wp2shell

### 💙 Support the Project

If you appreciate my work, consider supporting the project via **USDT (TRC20):** `TQBA72kakjCZLnJt8fJYcD7dyQCEpzNtVN`


## WordPress Core Pre-Authentication RCE Chain

**wp2shell** is a security research Proof-of-Concept demonstrating a
pre-authentication vulnerability chain in WordPress Core combining:

- **CVE-2026-63030** — REST API Batch route confusion
- **CVE-2026-60137** — `WP_Query` SQL injection

The chain demonstrates how these vulnerabilities can be combined to move
from an unauthenticated REST API request to SQL injection, privilege
escalation, administrator account creation, and ultimately authenticated
remote code execution.

> [!WARNING]
> ## Authorized Security Research Only
>
> This project is intended for:
>
> - Vulnerability research
> - Defensive validation
> - Authorized penetration testing
> - Security laboratories
> - CTFs and educational environments
>
> Only test systems that you own or have explicit written authorization
> to assess.
>
> Do not use this project against third-party infrastructure without
> authorization.

---

# Table of Contents

- [Overview](#overview)
- [Vulnerability Chain](#vulnerability-chain)
- [CVE-2026-63030](#cve-2026-63030)
- [CVE-2026-60137](#cve-2026-60137)
- [How the Chain Works](#how-the-chain-works)
- [Affected Versions](#affected-versions)
- [Preconditions](#preconditions)
- [Features](#features)
- [Interactive Menu](#interactive-menu)
- [Recommended Mode — Mode 3](#recommended-mode--mode-3)
- [Mode 1 — Fingerprint and Confirm](#mode-1--fingerprint-and-confirm)
- [Mode 2 — Blind SQL Extraction](#mode-2--blind-sql-extraction)
- [Mode 3 — Pre-Auth Admin Creation](#mode-3--pre-auth-admin-creation)
- [Mode 4 — Full RCE Chain](#mode-4--full-rce-chain)
- [Mode 5 — Facilitated Sink SQLi](#mode-5--facilitated-sink-sqli)
- [Mode 6 — Threaded URL Scan](#mode-6--threaded-url-scan)
- [Mode 7 — Transport Settings](#mode-7--transport-settings)
- [Mode 8 — Change Target URL](#mode-8--change-target-url)
- [Single Target vs URL List](#single-target-vs-url-list)
- [Detection Logic](#detection-logic)
- [Technical Chain](#technical-chain)
- [Route Variants](#route-variants)
- [SQLite Support](#sqlite-support)
- [Installation](#installation)
- [Security Impact](#security-impact)
- [Defensive Detection](#defensive-detection)
- [Mitigation](#mitigation)
- [Credits](#credits)
- [References](#references)
- [Disclaimer](#disclaimer)

---

# Overview

`wp2shell` is a unified WordPress Core security research tool for
investigating the interaction between two vulnerabilities:

```text
CVE-2026-63030
        |
        v
REST API Batch Route Confusion
        |
        v
Validation / Dispatch Confusion
        |
        v
CVE-2026-60137
        |
        v
WP_Query SQL Injection
        |
        v
Blind SQL Access
        |
        v
Application / Object-State Manipulation
        |
        v
Privilege Escalation
        |
        v
Administrator Account Creation
        |
        v
Authenticated Code Execution
````

The PoC is implemented as a Python research tool and uses the Python
standard library without requiring third-party Python packages.

---

# Vulnerability Chain

The project combines two WordPress Core vulnerabilities.

```text
                    Unauthenticated Request
                              |
                              v
                   +----------------------+
                   |   CVE-2026-63030     |
                   | REST Batch Route     |
                   |      Confusion       |
                   +----------+-----------+
                              |
                              v
                    Validation Confusion
                              |
                              v
                   +----------------------+
                   |   CVE-2026-60137     |
                   |   WP_Query SQLi      |
                   +----------+-----------+
                              |
                              v
                       Blind SQLi
                              |
                              v
                 Application-State Abuse
                              |
                              v
                    Privilege Escalation
                              |
                              v
                   Administrator Access
                              |
                              v
                    Authenticated RCE
```

The important security property is the interaction between the two
vulnerabilities rather than either vulnerability in isolation.

---

# CVE-2026-63030

## REST API Batch Route Confusion

The first vulnerability affects processing of requests through the
WordPress REST API Batch endpoint.

The batch implementation maintains request matching and validation
information in parallel structures indexed by request position.

A malformed sub-request can cause those structures to become
desynchronized.

This creates an off-by-one dispatch condition where a later request can
be processed using a handler or validation context associated with
another request.

Conceptually:

```text
Request A
   |
   +-- validation entry
   +-- matching entry
   |
   v
Malformed request
   |
   +-- internal state becomes desynchronized
   |
   v
Request B
   |
   +-- unexpected handler / validation context
```

The PoC performs behavioral checks to determine whether the route
confusion is actually reachable.

---

# CVE-2026-60137

## WP_Query SQL Injection

The second vulnerability affects a `WP_Query` SQL processing path.

Once the route-confusion primitive is established, attacker-controlled
input can reach the vulnerable query path.

The PoC demonstrates the resulting SQL injection through blind
differential testing.

The research functionality includes:

* Boolean-blind confirmation
* Optional time-based corroboration
* Database fingerprinting
* Supported scalar extraction
* WordPress user-data research

---

# How the Chain Works

## 1. REST Batch Route Confusion

An unauthenticated request reaches the WordPress REST Batch endpoint.

A malformed batch sub-request causes the internal request matching and
validation state to become desynchronized.

A later request can consequently be processed using an unintended
context.

---

## 2. SQL Injection

The route-confusion primitive provides the path needed for the second
vulnerability.

An attacker-controlled value can reach the vulnerable `WP_Query`
processing path.

This creates a blind SQL injection primitive.

---

## 3. Blind SQL Extraction

The SQL injection can be used as a boolean-blind extraction channel.

The PoC contains functionality for researching database information and
supported WordPress user information.

---

## 4. Application-State Manipulation

The chain uses database-controlled results to influence WordPress
application objects and subsequent processing.

This provides the primitives needed by the privilege-escalation stage.

---

## 5. Changeset Escalation

The chain uses WordPress changeset processing to establish an
administrator execution context.

A fabricated `customize_changeset` object can participate in the
privilege-escalation sequence.

---

## 6. Hook Re-entry

The chain re-enters WordPress request processing through the application
request lifecycle.

This allows subsequent API processing to occur under the elevated
context.

---

## 7. Administrator Account Creation

The research PoC implements a pre-authentication administrator creation
stage.

This is the key reason Mode 3 is useful for security validation: it
demonstrates the privilege-escalation impact without continuing into the
webshell/RCE stage.

---

## 8. Authenticated Code Execution

Mode 4 extends the research chain beyond administrator creation into the
authenticated code-execution stage.

This stage should only be used in an isolated laboratory or an explicitly
authorized assessment.

---

# Affected Versions

## Complete Pre-Authentication Chain

| WordPress Version | Status         |
| ----------------- | -------------- |
| 6.9.0 – 6.9.4     | **Vulnerable** |
| 7.0.0 – 7.0.1     | **Vulnerable** |
| 6.9.5             | **Fixed**      |
| 7.0.2+            | **Fixed**      |

The PoC identifies `6.9.0–6.9.4` and `7.0.0–7.0.1` as the documented
full-chain vulnerable versions.

## SQL Injection

The SQL injection component has a different fixed-version boundary from
the complete chain.

The research implementation identifies `6.8.6` as the SQL injection fix.

The complete unauthenticated chain additionally depends on the
vulnerable REST Batch behavior.

Always verify affected and fixed versions against the relevant official
security advisory before making production decisions.

---

# Preconditions

The PoC documents these conditions for the complete chain:

* WordPress REST API is reachable
* No Redis/Memcached object cache
* At least one published post

Other deployment components may affect reproducibility:

* Reverse proxies
* Web Application Firewalls
* REST API restrictions
* Security plugins
* Object caching
* HTTP filtering
* Hosting configuration

A WordPress installation matching the version range does not
automatically mean that the complete chain will work in every
environment.

---

# Features

`wp2shell` provides an interactive menu containing the following
research functions:

```text
[1] Fingerprint + confirm vulnerability (non-destructive)
[2] Blind SQL extraction  (fingerprint / dump users)
[3] Pre-Auth Admin creation
[4] Full RCE chain  →  admin creation + webshell
[5] Facilitated sink SQLi  (WordPress 6.8.x / custom)
[6] Threaded scan over URL list
[7] Transport settings  (proxy, TLS, timeout, delay)
[8] Change target URL
[0] Quit
```

---

# Interactive Menu

The main menu is designed to support both:

* Testing a single authorized WordPress installation
* Testing an authorized list of WordPress URLs

The workflow can therefore be used for both individual research targets
and larger authorized assessment datasets.

---

# Recommended Mode — Mode 3

## Why Mode 3?

For vulnerability research, **Mode 3 is the recommended mode when the
goal is to demonstrate the security impact without deploying a
webshell**.

Mode 3 is:

```text
Pre-Auth Admin Creation
```

The PoC describes this stage as:

```text
Unauthenticated UNION SQLi → new WordPress administrator
```

and explicitly distinguishes it from the full webshell/RCE stage:

```text
No password cracking.
No webshell.
Non-destructive admin only.
```

This makes Mode 3 particularly useful when you want to prove that the
vulnerability chain reaches administrator-level compromise while
avoiding the additional code-execution stage.

---

# Mode 3 — Pre-Auth Admin Creation

Selecting Mode 3 opens:

```text
────────────────────────────────────────────────────────────
  CREATE ADMIN — Pre-Auth Admin RCE Chain
────────────────────────────────────────────────────────────
  ⚠  Unauthenticated UNION SQLi → new WordPress administrator.
  ⚠  No password cracking. No webshell. Non-destructive admin only.
```

The PoC then asks for several environment and output options.

## SQLite

```text
→ Target uses SQLite? (WP-SQLite plugin) (y/N) [n]:
```

Set this to `y` when the authorized target uses a WordPress SQLite
configuration supported by the PoC.

For normal MySQL/MariaDB WordPress installations, the default is:

```text
n
```

---

## Credential Verification

The PoC can optionally verify the generated credentials by attempting
an authenticated login:

```text
→ Verify the generated credentials by logging in? (Y/n) [y]:
```

The default is:

```text
y
```

This is useful when you want the result to include confirmation that
the generated administrator credentials actually authenticate.

---

## Output File

Mode 3 can save results to a local file:

```text
→ Output file (blank = skip, e.g. result.txt):
```

For example:

```text
logs.txt
```

Leaving the field blank skips file output.

The output option is useful when performing authorized research across
multiple targets and wanting to retain the results for later analysis.

---

## Confusion Carrier

The PoC provides two carrier variants:

```text
→ Confusion carrier variant (posts/categories) [posts]:
```

Available choices:

```text
posts
categories
```

The default is:

```text
posts
```

The `posts` variant is the primary documented path.

---

# Mode 1 — Fingerprint and Confirm

Mode 1 is:

```text
[1] Fingerprint + confirm vulnerability (non-destructive)
```

This is the safest starting point for vulnerability validation.

It focuses on determining whether the target exhibits the behavioral
conditions associated with the vulnerability chain.

The check stage can include:

* WordPress fingerprinting
* REST Batch endpoint checks
* Route-confusion confirmation
* SQL injection confirmation
* Boolean-blind differential testing
* Optional time-based corroboration

Use Mode 1 when the goal is primarily:

```text
"Is this target potentially vulnerable?"
```

rather than demonstrating administrator impact.

---

# Mode 2 — Blind SQL Extraction

Mode 2 is:

```text
[2] Blind SQL extraction  (fingerprint / dump users)
```

This mode demonstrates the SQL injection primitive through blind
extraction.

Research functionality includes:

* Database fingerprinting
* Database version
* Database user
* Database name
* Supported scalar SQL expressions
* WordPress user information

Use this mode only in an authorized environment because it demonstrates
data-access impact rather than merely detecting the vulnerability.

---

# Mode 3 — Pre-Auth Admin Creation

Mode 3 is:

```text
[3] Pre-Auth Admin creation
```

This mode demonstrates the privilege-escalation impact of the chain.

The important distinction is:

```text
Mode 3
    |
    +-- Pre-authentication chain
    +-- Administrator creation
    +-- Optional login verification
    +-- No password cracking
    +-- No webshell
```

For security researchers who need to prove the vulnerability's
administrator-level impact without deploying a webshell, this is the
preferred mode.

---

# Mode 4 — Full RCE Chain

Mode 4 is:

```text
[4] Full RCE chain → admin creation + webshell
```

This extends the chain beyond administrator creation into authenticated
code execution.

Conceptually:

```text
Unauthenticated
      ↓
Route Confusion
      ↓
SQL Injection
      ↓
Privilege Escalation
      ↓
Administrator Creation
      ↓
Administrator Authentication
      ↓
Webshell
      ↓
Code Execution
```

This mode should be restricted to isolated laboratories and explicitly
authorized penetration tests.

For ordinary vulnerability validation, Mode 3 is preferable because it
demonstrates the administrator-impact boundary without deploying a
webshell.

---

# Mode 5 — Facilitated Sink SQLi

Mode 5 is:

```text
[5] Facilitated sink SQLi (WordPress 6.8.x / custom)
```

This mode is intended for research involving the SQL injection sink
outside the complete pre-authentication chain.

It is useful for researchers investigating:

* WordPress 6.8.x environments
* Custom configurations
* The SQL injection primitive independently
* Vulnerability reproduction
* Defensive validation

---

# Mode 6 — Threaded URL Scan

Mode 6 is:

```text
[6] Threaded scan over URL list
```

This mode is intended for authorized assessments involving multiple
WordPress targets.

Instead of manually testing one URL at a time, the tool can process a
URL list using worker threads.

Conceptually:

```text
urls.txt
   |
   +-- URL 1
   +-- URL 2
   +-- URL 3
   +-- URL 4
   +-- ...
   |
   v
Threaded vulnerability checks
   |
   v
Results
```

The scan functionality can use options such as:

* Worker thread count
* Confirmation delay
* Optional version proof
* JSON report output
* Confusion carrier variant

Use this only with URL lists for which you have explicit authorization.

---

# Single Target vs URL List

`wp2shell` can be used in two general ways.

## Single WordPress Target

Use a single target when researching one installation.

Typical use cases:

* Local laboratory
* Staging environment
* Customer-approved penetration test
* Vulnerability reproduction
* CVE verification

The target should be a WordPress base URL.

---

## URL List

For multiple authorized targets, Mode 6 can process a URL list.

Example conceptual file:

```text
https://wordpress-lab-01.example
https://wordpress-lab-02.example
https://wordpress-lab-03.example
https://wordpress-lab-04.example
```

The threaded scanner can then process the list and record the results.

The scan implementation also supports an output/report option for
retaining findings.

---

# Mode Selection Guide

| Goal                                   | Recommended Mode |
| -------------------------------------- | ---------------- |
| Check whether a target is vulnerable   | **Mode 1**       |
| Demonstrate SQL injection              | **Mode 2**       |
| Demonstrate administrator-level impact | **Mode 3**       |
| Demonstrate complete RCE chain         | **Mode 4**       |
| Research the SQLi sink independently   | **Mode 5**       |
| Test an authorized URL list            | **Mode 6**       |
| Configure proxy/TLS/timeout/delay      | **Mode 7**       |
| Change the current target              | **Mode 8**       |

### Recommended research workflow

For most security assessments:

```text
Mode 1
  ↓
Confirm vulnerability
  ↓
Mode 3
  ↓
Demonstrate administrator impact
```

Only continue to Mode 4 when full code-execution validation is explicitly
required and authorized.

---

# Mode 7 — Transport Settings

Mode 7 is:

```text
[7] Transport settings (proxy, TLS, timeout, delay)
```

This section controls the HTTP transport behavior used by the tool.

Supported research settings include:

* Proxy configuration
* TLS behavior
* Request timeout
* Request delay
* Connection/retry behavior

These options are useful when testing WordPress installations behind:

* Proxies
* TLS configurations
* Slow connections
* Rate-limiting infrastructure
* Controlled lab environments

---

# Mode 8 — Change Target URL

Mode 8 is:

```text
[8] Change target URL
```

This allows the currently selected target to be changed without
restarting the entire interactive workflow.

It is useful when moving between authorized laboratory installations.

---

# Detection Logic

The PoC uses behavioral checks instead of relying exclusively on a
WordPress version string.

## REST Batch Detection

The tool verifies that the REST Batch endpoint is reachable.

## Route Confusion Detection

The tool can use:

* Response markers
* Structural response behavior

The structural approach checks whether a request intended for one REST
collection is processed as another collection.

## SQL Injection Detection

The tool can perform a boolean-blind differential.

A time-based channel can additionally be used as corroboration.

---

# Technical Chain

The complete research chain can be summarized as:

```text
1. REST API reachable
          |
          v
2. Batch route confusion
          |
          v
3. Validation / dispatch confusion
          |
          v
4. SQL injection reaches WP_Query
          |
          v
5. Blind SQL channel
          |
          v
6. Application-state manipulation
          |
          v
7. Changeset privilege escalation
          |
          v
8. Administrator context
          |
          v
9. Administrator account creation
          |
          v
10. Authenticated code execution
```

---

# Route Variants

The PoC supports two confusion-carrier variants:

```text
posts
categories
```

The default is:

```text
posts
```

The `posts` variant is the primary documented end-to-end carrier.

The `categories` variant provides an alternative route-confusion path
for research.

---

# SQLite Support

The PoC contains SQLite compatibility support for environments using a
WordPress SQLite configuration.

Mode 3 exposes this option as:

```text
Target uses SQLite? (WP-SQLite plugin)
```

Default:

```text
n
```

Use:

```text
y
```

when the authorized target uses the supported SQLite configuration.

---

# Installation

The PoC uses Python's standard library.

No third-party Python packages are required.

Required environment:

```text
Python 3.x
```

Clone the repository and run the research tool inside an isolated or
explicitly authorized environment.

---

# Project Structure

A recommended repository structure is:

```text
wp2shell/
│
├── wp2shell.py
├── README.md
├── LICENSE
└── screenshots/
```

The main research implementation is:

```text
wp2shell.py
```

---

# Security Impact

A successful exploitation chain can potentially result in:

* Unauthenticated SQL injection
* Database information disclosure
* WordPress user information exposure
* Privilege escalation
* Administrator account creation
* Full WordPress administrative access
* Authenticated arbitrary code execution
* Potential operating-system-level compromise depending on the hosting
  environment

The complete chain therefore has significantly greater impact than the
individual vulnerabilities considered independently.

---

# Defensive Detection

Administrators should investigate suspicious activity involving:

* WordPress REST Batch endpoints
* Abnormal nested batch requests
* Malformed batch request paths
* Suspicious query parameters
* Unexpected administrator account creation
* Unexpected `customize_changeset` activity
* Unexpected plugin installations
* Unexpected PHP files
* Suspicious plugin modifications
* Webshell-like behavior

Review:

```text
Web server logs
        +
WordPress logs
        +
Database audit logs
        +
File integrity monitoring
```

especially around the time of suspected exploitation.

---

# Mitigation

The primary mitigation is upgrading WordPress to a fixed release.

Affected installations should also:

1. Review all administrator accounts.
2. Remove unauthorized administrator accounts.
3. Review recently installed or modified plugins.
4. Review WordPress REST API logs.
5. Review web-server access logs.
6. Search for unexpected PHP files.
7. Check plugin directories for unauthorized modifications.
8. Rotate credentials if compromise is suspected.
9. Review database integrity.
10. Remove persistence mechanisms.
11. Reinstall compromised WordPress components from trusted sources when
    appropriate.

---

# Responsible Research Workflow

For a normal authorized assessment, the recommended progression is:

```text
                 START
                   |
                   v
          ┌─────────────────┐
          │     MODE 1      │
          │ Detect / Confirm│
          └────────┬────────┘
                   |
             Vulnerable?
              /          \
            No            Yes
            |              |
           STOP            v
                    ┌───────────────┐
                    │    MODE 3     │
                    │ Admin Impact  │
                    └───────┬───────┘
                            |
                     Need full RCE?
                       /          \
                     No            Yes
                     |              |
                    STOP            v
                             ┌───────────────┐
                             │    MODE 4     │
                             │ Full RCE Lab  │
                             └───────────────┘
```

Mode 3 is generally the preferred impact-demonstration point because it
establishes administrator-level compromise without deploying the
webshell stage.

---

# Research vs Production

This project is intended for controlled security research.

Do not treat the tool as a general-purpose Internet scanner.

For production environments:

* Obtain written authorization.
* Define the target scope.
* Define allowed actions.
* Prefer non-destructive verification.
* Stop after sufficient evidence has been collected.
* Preserve logs and evidence.
* Follow the applicable vulnerability disclosure process.

---

# Credits

Vulnerability research / discovery:

**Adam Kues**
Assetnote / Searchlight Cyber

Project:

**wp2shell**

The research implementation identifies the vulnerability chain as:

```text
CVE-2026-63030
+
CVE-2026-60137
```

---

# References

* CVE-2026-63030
* CVE-2026-60137
* GHSA-ff9f-jf42-662q
* GHSA-fpp7-x2x2-2mjf
* WordPress Core
* WordPress REST API
* WordPress `WP_Query`

---

# Disclaimer

This repository contains security research demonstrating a vulnerability
chain affecting WordPress Core.

The software and documentation are provided for:

* Educational purposes
* Security research
* Vulnerability verification
* Defensive testing
* Authorized penetration testing

The authors are not responsible for unauthorized or malicious use of
this material.

**Only test systems you own or systems for which you have explicit
authorization.**

---

# Keywords

```text
wp2shell
WordPress
WordPress Core
WordPress Security
WordPress Vulnerability
WordPress RCE
Pre-Auth RCE
Pre-Authentication RCE
CVE-2026-63030
CVE-2026-60137
REST API
REST Batch
REST API Batch
Route Confusion
WP_Query
SQL Injection
SQLi
Blind SQL Injection
Privilege Escalation
Administrator Creation
Remote Code Execution
RCE
Proof of Concept
PoC
Security Research
Penetration Testing
```

---

## Repository Topics

Recommended GitHub repository topics:

```text
wp2shell
wordpress
wordpress-core
wordpress-security
wordpress-vulnerability
wordpress-rce
cve
cve-2026-63030
cve-2026-60137
poc
proof-of-concept
rce
sql-injection
sqli
blind-sqli
rest-api
security-research
penetration-testing
privilege-escalation
```

---

## Project Summary

```text
wp2shell is a WordPress Core pre-authentication vulnerability-chain PoC
combining CVE-2026-63030 (REST API Batch route confusion) and
CVE-2026-60137 (WP_Query SQL injection), demonstrating the progression
from unauthenticated access to SQL injection, privilege escalation,
administrator creation, and authenticated code execution.
```

```
disclaimer: this project is for educational purposes only
```
